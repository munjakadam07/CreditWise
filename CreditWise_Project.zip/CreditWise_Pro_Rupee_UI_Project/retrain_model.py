import pandas as pd
import joblib

from sklearn.model_selection import train_test_split
from sklearn.compose import ColumnTransformer
from sklearn.pipeline import Pipeline
from sklearn.impute import SimpleImputer
from sklearn.preprocessing import StandardScaler, OneHotEncoder
from sklearn.ensemble import GradientBoostingClassifier
from sklearn.metrics import (
    accuracy_score,
    precision_score,
    recall_score,
    f1_score,
    roc_auc_score
)

DATA_PATH = "loan_approval_data.csv"
MODEL_PATH = "creditwise_model.joblib"

# Load data
df = pd.read_csv(DATA_PATH)
print("Dataset loaded:", df.shape)

# Keep only rows with an actual target
df = df[df["Loan_Approved"].notna()].copy()
print("Labeled rows:", len(df))

# Convert Yes/No target to 1/0
df["Loan_Approved"] = (
    df["Loan_Approved"]
    .astype(str)
    .str.strip()
    .str.lower()
    .map({
        "yes": 1,
        "approved": 1,
        "1": 1,
        "true": 1,
        "no": 0,
        "rejected": 0,
        "0": 0,
        "false": 0
    })
)

# Remove any unknown target values
df = df[df["Loan_Approved"].notna()].copy()

X = df.drop(
    columns=["Loan_Approved", "Applicant_ID"],
    errors="ignore"
)

y = df["Loan_Approved"].astype(int)

print("\nTarget distribution:")
print(y.value_counts())

numeric_features = [
    "Applicant_Income",
    "Coapplicant_Income",
    "Age",
    "Dependents",
    "Credit_Score",
    "Existing_Loans",
    "DTI_Ratio",
    "Savings",
    "Collateral_Value",
    "Loan_Amount",
    "Loan_Term"
]

categorical_features = [
    "Employment_Status",
    "Marital_Status",
    "Loan_Purpose",
    "Property_Area",
    "Education_Level",
    "Gender",
    "Employer_Category"
]

numeric_features = [c for c in numeric_features if c in X.columns]
categorical_features = [c for c in categorical_features if c in X.columns]

numeric_pipeline = Pipeline([
    ("imputer", SimpleImputer(strategy="median")),
    ("scaler", StandardScaler())
])

categorical_pipeline = Pipeline([
    ("imputer", SimpleImputer(strategy="most_frequent")),
    ("encoder", OneHotEncoder(handle_unknown="ignore"))
])

preprocessor = ColumnTransformer([
    ("num", numeric_pipeline, numeric_features),
    ("cat", categorical_pipeline, categorical_features)
])

model = GradientBoostingClassifier(random_state=42)

pipeline = Pipeline([
    ("preprocessor", preprocessor),
    ("model", model)
])

X_train, X_test, y_train, y_test = train_test_split(
    X,
    y,
    test_size=0.20,
    random_state=42,
    stratify=y
)

print("\nTraining model...")
pipeline.fit(X_train, y_train)

y_pred = pipeline.predict(X_test)
y_prob = pipeline.predict_proba(X_test)[:, 1]

print("\n========== MODEL PERFORMANCE ==========")
print(f"Accuracy : {accuracy_score(y_test, y_pred):.4f}")
print(f"Precision: {precision_score(y_test, y_pred):.4f}")
print(f"Recall   : {recall_score(y_test, y_pred):.4f}")
print(f"F1 Score : {f1_score(y_test, y_pred):.4f}")
print(f"ROC-AUC  : {roc_auc_score(y_test, y_prob):.4f}")
print("=======================================\n")

# Save new model using YOUR current environment
joblib.dump(pipeline, MODEL_PATH)

print(f"Model successfully saved as: {MODEL_PATH}")

# Verify model can be loaded
print("\nTesting saved model...")

test_model = joblib.load(MODEL_PATH)

print("SUCCESS: Model can be loaded in this environment.")
print("Model type:", type(test_model))