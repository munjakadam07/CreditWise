"""Database backup, verification, and restore utility for CreditWise SQLite storage.

Usage:
    python -m backend.db_backup backup [--dest backups/]
    python -m backend.db_backup verify [--file path/to/db]
    python -m backend.db_backup restore --file backups/creditwise_backup_XYZ.db
"""

import argparse
import os
import shutil
import sqlite3
import sys
from datetime import datetime, timezone
from pathlib import Path

ROOT_DIR = Path(__file__).resolve().parent.parent
DEFAULT_DB = Path(os.getenv("DATABASE_PATH", ROOT_DIR / "creditwise_app.db"))
BACKUPS_DIR = ROOT_DIR / "backups"


def perform_online_backup(source_path: Path = DEFAULT_DB, dest_dir: Path = BACKUPS_DIR) -> Path:
    """Use SQLite's online backup API to take a non-blocking snapshot."""
    if not source_path.exists():
        raise FileNotFoundError(f"Source database not found at {source_path}")

    dest_dir.mkdir(parents=True, exist_ok=True)
    timestamp = datetime.now(timezone.utc).strftime("%Y%m%d_%H%M%S")
    backup_file = dest_dir / f"creditwise_backup_{timestamp}.db"

    # Online backup prevents lock contention and guarantees consistency with WAL journal
    src_conn = sqlite3.connect(str(source_path))
    dst_conn = sqlite3.connect(str(backup_file))
    try:
        src_conn.backup(dst_conn, pages=100, sleep=0.01)
        print(f"[SUCCESS] Database successfully backed up to: {backup_file}")
    finally:
        dst_conn.close()
        src_conn.close()

    verify_database(backup_file)
    return backup_file


def verify_database(db_file: Path) -> bool:
    """Run SQLite integrity check and foreign-key check."""
    if not db_file.exists():
        print(f"[ERROR] Database file does not exist: {db_file}", file=sys.stderr)
        return False

    conn = sqlite3.connect(str(db_file))
    try:
        # Integrity check
        cur = conn.cursor()
        cur.execute("PRAGMA integrity_check;")
        integrity = cur.fetchone()[0]
        if integrity != "ok":
            print(f"[ERROR] Integrity check failed on {db_file}: {integrity}", file=sys.stderr)
            return False

        # Foreign key check
        cur.execute("PRAGMA foreign_key_check;")
        fk_violations = cur.fetchall()
        if fk_violations:
            print(f"[ERROR] Foreign key violations found: {fk_violations}", file=sys.stderr)
            return False

        # Record count telemetry
        cur.execute("SELECT COUNT(*) FROM users;")
        user_count = cur.fetchone()[0]
        cur.execute("SELECT COUNT(*) FROM predictions;")
        pred_count = cur.fetchone()[0]

        print(f"[INFO] Verified '{db_file.name}': Integrity OK, FKs OK. Users: {user_count}, Predictions: {pred_count}")
        return True
    finally:
        conn.close()


def restore_database(backup_file: Path, target_path: Path = DEFAULT_DB) -> bool:
    """Restore target database from a verified backup file after making an emergency rollback snapshot."""
    if not backup_file.exists():
        print(f"[ERROR] Backup file not found: {backup_file}", file=sys.stderr)
        return False

    if not verify_database(backup_file):
        print("[ERROR] Restore aborted: The backup file failed integrity checks.", file=sys.stderr)
        return False

    # Emergency safety backup of current state if exists
    if target_path.exists():
        safety_path = target_path.parent / f"{target_path.stem}_pre_restore_{datetime.now(timezone.utc).strftime('%Y%m%d_%H%M%S')}.db"
        shutil.copy2(target_path, safety_path)
        print(f"[INFO] Created emergency pre-restore snapshot: {safety_path}")

    # Copy backup to target
    shutil.copy2(backup_file, target_path)
    print(f"[SUCCESS] Database successfully restored to {target_path} from {backup_file}")
    verify_database(target_path)
    return True


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="CreditWise Database Backup and Verification Tool")
    subparsers = parser.add_subparsers(dest="command", required=True)

    # Backup subparser
    backup_parser = subparsers.add_parser("backup", help="Create an online snapshot of the database")
    backup_parser.add_argument("--source", type=Path, default=DEFAULT_DB)
    backup_parser.add_argument("--dest", type=Path, default=BACKUPS_DIR)

    # Verify subparser
    verify_parser = subparsers.add_parser("verify", help="Check database integrity and foreign keys")
    verify_parser.add_argument("--file", type=Path, default=DEFAULT_DB)

    # Restore subparser
    restore_parser = subparsers.add_parser("restore", help="Restore database from a backup file")
    restore_parser.add_argument("--file", type=Path, required=True)
    restore_parser.add_argument("--target", type=Path, default=DEFAULT_DB)

    args = parser.parse_args()

    if args.command == "backup":
        perform_online_backup(args.source, args.dest)
    elif args.command == "verify":
        ok = verify_database(args.file)
        sys.exit(0 if ok else 1)
    elif args.command == "restore":
        ok = restore_database(args.file, args.target)
        sys.exit(0 if ok else 1)
