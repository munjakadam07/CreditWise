"""Dedicated Phase 6 review test suite verifying production fail-closed security, backup/restore, and admin idempotency."""

import os
import shutil
import sqlite3
import tempfile
from pathlib import Path
import pytest
from fastapi import HTTPException
from fastapi.testclient import TestClient

import backend.main as main_mod
from backend.auth import hash_password, verify_password
from backend.db_backup import perform_online_backup, restore_database, verify_database
from backend.seed_admin import seed_administrator


def test_production_fails_closed_on_missing_or_weak_secrets():
    """Verify production rejects empty, default, or short SECRET_KEY."""
    original_env = main_mod.ENVIRONMENT
    original_secret = main_mod.SECRET_KEY
    original_origins = os.environ.get("ALLOWED_ORIGINS")

    try:
        main_mod.ENVIRONMENT = "production"
        os.environ["ALLOWED_ORIGINS"] = "https://creditwise.example.com"

        # 1. Empty SECRET_KEY
        main_mod.SECRET_KEY = ""
        with pytest.raises(RuntimeError) as exc_empty:
            main_mod.validate_production_configuration()
        assert "CRITICAL SECURITY CONFIGURATION ERROR" in str(exc_empty.value)

        # 2. Default Dev Secret
        main_mod.SECRET_KEY = "creditwise_dev_jwt_secret_key_minimum_32_characters_long_2026"
        with pytest.raises(RuntimeError) as exc_default:
            main_mod.validate_production_configuration()
        assert "Using the default key is prohibited" in str(exc_default.value)

        # 3. Short secret (< 32 characters)
        main_mod.SECRET_KEY = "too_short_key_12345"
        with pytest.raises(RuntimeError) as exc_short:
            main_mod.validate_production_configuration()
        assert "at least 32 characters" in str(exc_short.value)

        # 4. Valid strong secret passes
        main_mod.SECRET_KEY = "a_very_strong_cryptographically_secure_production_secret_key_2026_x99!"
        # Should not raise exception
        main_mod.validate_production_configuration()
    finally:
        main_mod.ENVIRONMENT = original_env
        main_mod.SECRET_KEY = original_secret
        if original_origins:
            os.environ["ALLOWED_ORIGINS"] = original_origins


def test_production_fails_closed_on_wildcard_cors():
    """Verify production rejects wildcard or missing CORS origin configuration."""
    original_env = main_mod.ENVIRONMENT
    original_secret = main_mod.SECRET_KEY
    original_origins = os.environ.get("ALLOWED_ORIGINS")

    try:
        main_mod.ENVIRONMENT = "production"
        main_mod.SECRET_KEY = "a_very_strong_cryptographically_secure_production_secret_key_2026_x99!"

        # Wildcard CORS is prohibited in production
        os.environ["ALLOWED_ORIGINS"] = "*"
        with pytest.raises(RuntimeError) as exc_wildcard:
            main_mod.validate_production_configuration()
        assert "must not contain wildcards" in str(exc_wildcard.value)

        # Missing ALLOWED_ORIGINS is prohibited
        os.environ["ALLOWED_ORIGINS"] = ""
        with pytest.raises(RuntimeError) as exc_missing:
            main_mod.validate_production_configuration()
        assert "must be set to explicit trusted frontend origins" in str(exc_missing.value)
    finally:
        main_mod.ENVIRONMENT = original_env
        main_mod.SECRET_KEY = original_secret
        if original_origins:
            os.environ["ALLOWED_ORIGINS"] = original_origins


def test_production_error_masking():
    """Verify that in production mode, unhandled internal errors return generic 500 without stack trace."""
    original_env = main_mod.ENVIRONMENT
    try:
        main_mod.ENVIRONMENT = "production"
        client = TestClient(main_mod.app, raise_server_exceptions=False)

        # Request health check to verify endpoint works
        health = client.get("/health")
        assert health.status_code == 200

        # Verify that an internal error handler masks internal details
        class MockRequest:
            pass

        import asyncio
        response = asyncio.run(main_mod.global_exception_handler(MockRequest(), ValueError("Sensitive DB Connection String Details")))
        assert response.status_code == 500
        import json
        body = json.loads(response.body.decode())
        assert body["detail"] == "An internal server error occurred. Please contact system support."
        assert "Sensitive" not in body["detail"]
    finally:
        main_mod.ENVIRONMENT = original_env


def test_disposable_database_backup_and_restore():
    """Verify SQLite backup and restore operations using a completely disposable test database."""
    temp_dir = Path(tempfile.mkdtemp())
    try:
        src_db = temp_dir / "disposable_src.db"
        backups_dir = temp_dir / "backups"
        restored_db = temp_dir / "disposable_restored.db"

        # 1. Create a disposable test schema with foreign keys
        conn = sqlite3.connect(str(src_db))
        conn.execute("PRAGMA foreign_keys = ON;")
        conn.execute("PRAGMA journal_mode = WAL;")
        conn.execute("""
            CREATE TABLE users (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                email TEXT UNIQUE NOT NULL,
                role TEXT NOT NULL
            );
        """)
        conn.execute("""
            CREATE TABLE predictions (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
                prediction INTEGER NOT NULL
            );
        """)
        conn.execute("INSERT INTO users (email, role) VALUES ('disposable@test.local', 'customer');")
        conn.execute("INSERT INTO predictions (user_id, prediction) VALUES (1, 1);")
        conn.commit()
        conn.close()

        # 2. Perform online backup
        backup_file = perform_online_backup(source_path=src_db, dest_dir=backups_dir)
        assert backup_file.exists()

        # 3. Verify backup file integrity
        assert verify_database(backup_file) is True

        # 4. Restore backup file to a separate target path
        success = restore_database(backup_file=backup_file, target_path=restored_db)
        assert success is True
        assert restored_db.exists()

        # 5. Verify restored database has identical records and passes integrity check
        assert verify_database(restored_db) is True
        restored_conn = sqlite3.connect(str(restored_db))
        cur = restored_conn.cursor()
        cur.execute("SELECT COUNT(*) FROM users;")
        assert cur.fetchone()[0] == 1
        cur.execute("SELECT COUNT(*) FROM predictions;")
        assert cur.fetchone()[0] == 1
        restored_conn.close()
    finally:
        shutil.rmtree(temp_dir, ignore_errors=True)


def test_admin_provisioning_idempotency_and_protection():
    """Verify administrator provisioning never downgrades an existing administrator or resets passwords unintentionally."""
    temp_dir = Path(tempfile.mkdtemp())
    test_db = temp_dir / "test_admin.db"
    original_db_path = os.environ.get("DATABASE_PATH")

    try:
        os.environ["DATABASE_PATH"] = str(test_db)

        # 1. First provisioning creates the admin
        success = seed_administrator(
            email="lead_admin@creditwise.local",
            password="InitialSecurePassword123!",
            full_name="Lead Administrator"
        )
        assert success is True

        # Retrieve password hash
        conn = sqlite3.connect(str(test_db))
        conn.row_factory = sqlite3.Row
        cur = conn.cursor()
        cur.execute("SELECT id, role, password_hash FROM users WHERE email = 'lead_admin@creditwise.local';")
        admin_row = cur.fetchone()
        assert admin_row["role"] == "admin"
        initial_hash = admin_row["password_hash"]
        conn.close()

        # 2. Running seed_administrator again must NOT overwrite password or downgrade role
        success_re_seed = seed_administrator(
            email="lead_admin@creditwise.local",
            password="AttemptedChangedPassword456!",
            full_name="Lead Administrator"
        )
        assert success_re_seed is True

        conn = sqlite3.connect(str(test_db))
        conn.row_factory = sqlite3.Row
        cur = conn.cursor()
        cur.execute("SELECT id, role, password_hash FROM users WHERE email = 'lead_admin@creditwise.local';")
        re_seeded_row = cur.fetchone()
        assert re_seeded_row["role"] == "admin"
        # Password hash MUST remain untouched
        assert re_seeded_row["password_hash"] == initial_hash
        assert verify_password("InitialSecurePassword123!", re_seeded_row["password_hash"]) is True
        assert verify_password("AttemptedChangedPassword456!", re_seeded_row["password_hash"]) is False
        conn.close()

        # 3. Weak password rejection
        weak_res = seed_administrator(
            email="new_admin@creditwise.local",
            password="short",
            full_name="Weak Admin"
        )
        assert weak_res is False
    finally:
        if original_db_path:
            os.environ["DATABASE_PATH"] = original_db_path
        shutil.rmtree(temp_dir, ignore_errors=True)
