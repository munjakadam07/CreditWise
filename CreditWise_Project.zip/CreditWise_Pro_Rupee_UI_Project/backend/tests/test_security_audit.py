"""Security audit test suite verifying rate limiting, SQL injection resilience, CORS, and deactivated account handling."""

import pytest
from fastapi.testclient import TestClient
from backend.auth import auth_rate_limiter, create_access_token
from backend.database import get_db, get_db_path


def test_rate_limiting_enforcement(client):
    """Verify that exceeding rate limits returns HTTP 429 Too Many Requests."""
    # Temporarily set limit to 3 for this test
    original_limit = auth_rate_limiter.limit
    auth_rate_limiter.limit = 3
    auth_rate_limiter.hits.clear()

    try:
        # 3 allowed attempts
        for _ in range(3):
            client.post("/auth/login", json={"email": "ratelimit@test.com", "password": "wrong"})

        # 4th attempt must be rejected with 429
        blocked = client.post("/auth/login", json={"email": "ratelimit@test.com", "password": "wrong"})
        assert blocked.status_code == 429
        assert "Rate limit exceeded" in blocked.json()["detail"]
    finally:
        auth_rate_limiter.limit = original_limit
        auth_rate_limiter.hits.clear()


def test_sql_injection_resilience(client):
    """SQL injection payloads in email and name fields are handled safely via parameterized queries."""
    sqli_payload = {
        "email": "test' OR '1'='1@example.com",
        "password": "Password123!",
        "full_name": "'; DROP TABLE users; --"
    }
    # Email format validation rejects invalid characters before query, or parameterizes safely
    response = client.post("/auth/register", json=sqli_payload)
    # Rejection by regex validation or duplicate check
    assert response.status_code in [422, 409, 201]

    # Verify users table remains intact
    with get_db() as conn:
        cursor = conn.cursor()
        cursor.execute("SELECT count(*) as cnt FROM users")
        assert cursor.fetchone()["cnt"] >= 1


def test_deactivated_account_blocked(client, customer_user_1):
    """A deactivated user account is rejected at login and cannot access protected endpoints."""
    # Deactivate customer 1
    with get_db() as conn:
        cursor = conn.cursor()
        cursor.execute("UPDATE users SET is_active = 0 WHERE id = ?", (customer_user_1["id"],))

    try:
        # Login attempt with deactivated account must return 403 Forbidden
        login_res = client.post(
            "/auth/login",
            json={"email": customer_user_1["email"], "password": customer_user_1["password"]}
        )
        assert login_res.status_code == 403
        assert "deactivated" in login_res.json()["detail"].lower()

        # Existing token of deactivated user must be rejected with 403
        me_res = client.get("/auth/me", headers=customer_user_1["headers"])
        assert me_res.status_code == 403
        assert "deactivated" in me_res.json()["detail"].lower()
    finally:
        # Re-activate user
        with get_db() as conn:
            cursor = conn.cursor()
            cursor.execute("UPDATE users SET is_active = 1 WHERE id = ?", (customer_user_1["id"],))


def test_cors_headers_handling(client):
    """Preflight OPTIONS request from allowed frontend returns valid CORS headers."""
    response = client.options(
        "/predictions",
        headers={
            "Origin": "http://localhost:5173",
            "Access-Control-Request-Method": "POST",
            "Access-Control-Request-Headers": "authorization,content-type"
        }
    )
    assert response.status_code == 200
    assert response.headers.get("access-control-allow-origin") == "http://localhost:5173"


def test_production_fails_safely_on_insecure_secret():
    """Application startup must fail immediately if ENVIRONMENT=production with insecure SECRET_KEY."""
    from backend.main import validate_production_configuration
    import backend.main as main_mod

    original_env = main_mod.ENVIRONMENT
    original_secret = main_mod.SECRET_KEY
    try:
        main_mod.ENVIRONMENT = "production"
        main_mod.SECRET_KEY = "too-short"
        with pytest.raises(RuntimeError) as exc_info:
            validate_production_configuration()
        assert "CRITICAL SECURITY CONFIGURATION ERROR" in str(exc_info.value)
    finally:
        main_mod.ENVIRONMENT = original_env
        main_mod.SECRET_KEY = original_secret
