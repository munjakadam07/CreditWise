"""Authentication, password security, and token validation tests."""

from datetime import timedelta
import pytest
from backend.auth import create_access_token, hash_password, verify_password


def test_argon2_password_hashing():
    """Verify that password hashing uses Argon2id and verifies correctly."""
    raw = "MySecretPassword123"
    hashed = hash_password(raw)

    assert hashed.startswith("$argon2id$")
    assert verify_password(raw, hashed) is True
    assert verify_password("WrongPassword123", hashed) is False


def test_customer_registration_success(client):
    """Test successful customer registration with token returned."""
    payload = {
        "email": "newuser@creditwise.local",
        "password": "Password1234",
        "full_name": "New Customer"
    }
    response = client.post("/auth/register", json=payload)
    assert response.status_code == 201
    data = response.json()
    assert "access_token" in data
    assert data["token_type"] == "bearer"
    assert data["user"]["email"] == "newuser@creditwise.local"
    assert data["user"]["role"] == "customer"


def test_duplicate_email_registration_rejected(client, customer_user_1):
    """Attempting to register with an existing email returns 409 Conflict."""
    payload = {
        "email": customer_user_1["email"],
        "password": "SomeOtherPassword999",
        "full_name": "Impostor"
    }
    response = client.post("/auth/register", json=payload)
    assert response.status_code == 409
    assert "already exists" in response.json()["detail"]


def test_password_complexity_validation(client):
    """Weak passwords without digits or letters must be rejected with 422."""
    # Only letters
    r1 = client.post("/auth/register", json={
        "email": "weak1@test.com", "password": "onlylettershere", "full_name": "Test"
    })
    assert r1.status_code == 422

    # Only digits
    r2 = client.post("/auth/register", json={
        "email": "weak2@test.com", "password": "1234567890", "full_name": "Test"
    })
    assert r2.status_code == 422

    # Too short
    r3 = client.post("/auth/register", json={
        "email": "weak3@test.com", "password": "short1", "full_name": "Test"
    })
    assert r3.status_code == 422


def test_login_success(client, customer_user_1):
    """Verify login with correct credentials returns valid JWT."""
    payload = {
        "email": customer_user_1["email"],
        "password": customer_user_1["password"]
    }
    response = client.post("/auth/login", json=payload)
    assert response.status_code == 200
    data = response.json()
    assert "access_token" in data
    assert data["user"]["email"] == customer_user_1["email"]


def test_login_invalid_password(client, customer_user_1):
    """Invalid password returns 401 Unauthorized."""
    payload = {
        "email": customer_user_1["email"],
        "password": "IncorrectPassword999"
    }
    response = client.post("/auth/login", json=payload)
    assert response.status_code == 401
    assert "Invalid email address or password" in response.json()["detail"]


def test_get_current_user_profile(client, customer_user_1):
    """Verify /auth/me returns current user profile when authenticated."""
    response = client.get("/auth/me", headers=customer_user_1["headers"])
    assert response.status_code == 200
    data = response.json()
    assert data["email"] == customer_user_1["email"]
    assert data["role"] == "customer"


def test_expired_token_rejected(client, customer_user_1):
    """Expired token must be rejected with 401."""
    expired_token = create_access_token(
        user_id=customer_user_1["id"],
        email=customer_user_1["email"],
        role="customer",
        expires_delta=timedelta(seconds=-10)
    )
    response = client.get("/auth/me", headers={"Authorization": f"Bearer {expired_token}"})
    assert response.status_code == 401
    assert "expired" in response.json()["detail"].lower()


def test_tampered_token_rejected(client, customer_user_1):
    """Tampered token signature must be rejected with 401."""
    tampered = customer_user_1["token"][:-5] + "XXXXX"
    response = client.get("/auth/me", headers={"Authorization": f"Bearer {tampered}"})
    assert response.status_code == 401


def test_admin_login_success_with_email(client, admin_user):
    """Admin can authenticate via POST /auth/admin/login with email."""
    response = client.post(
        "/auth/admin/login",
        json={"username": admin_user["email"], "password": admin_user["password"]}
    )
    assert response.status_code == 200
    data = response.json()
    assert "access_token" in data
    assert data["user"]["role"] == "admin"
    assert data["user"]["email"] == admin_user["email"]


def test_admin_login_success_with_username(client, admin_user):
    """Admin can authenticate via POST /auth/admin/login using 'admin' username."""
    response = client.post(
        "/auth/admin/login",
        json={"username": "admin", "password": admin_user["password"]}
    )
    assert response.status_code == 200
    data = response.json()
    assert "access_token" in data
    assert data["user"]["role"] == "admin"


def test_admin_login_invalid_credentials_rejected(client, admin_user):
    """Invalid administrator password returns 401 Unauthorized without leaking details."""
    response = client.post(
        "/auth/admin/login",
        json={"username": admin_user["email"], "password": "WrongPassword999!"}
    )
    assert response.status_code == 401
    assert "Invalid administrator credentials" in response.json()["detail"]


def test_admin_login_rejects_customer_account(client, customer_user_1):
    """Customer credentials entered into the admin login form must be rejected with 403."""
    response = client.post(
        "/auth/admin/login",
        json={"username": customer_user_1["email"], "password": customer_user_1["password"]}
    )
    assert response.status_code == 403
    assert "Customer credentials cannot be used" in response.json()["detail"]


def test_admin_auth_does_not_expose_password_or_secrets(client, admin_user):
    """Verify admin login response does not expose password hashes or sensitive fields."""
    response = client.post(
        "/auth/admin/login",
        json={"username": "admin", "password": admin_user["password"]}
    )
    assert response.status_code == 200
    data = response.json()
    user = data["user"]
    assert "password" not in user
    assert "password_hash" not in user
    assert "hashed" not in str(data).lower()

