"""Tests for model training, evaluation integrity, artifact consistency, and leakage safety."""

import json
from pathlib import Path
import joblib
import numpy as np
import pandas as pd
import pytest
from sklearn.metrics import accuracy_score, confusion_matrix, roc_auc_score
from sklearn.model_selection import train_test_split

ROOT_DIR = Path(__file__).resolve().parent.parent.parent
DATA_PATH = ROOT_DIR / "data" / "loan_approval_data.csv"
METRICS_PATH = ROOT_DIR / "data" / "verified_model_metrics.json"
CM_PATH = ROOT_DIR / "data" / "confusion_matrices.json"
MODELS_DIR = ROOT_DIR / "backend" / "models"


def test_no_unlabeled_records_in_training_or_evaluation():
    """Verify that rows with missing Loan_Approved are excluded."""
    df = pd.read_csv(DATA_PATH)
    assert len(df) == 1000
    missing_count = df["Loan_Approved"].isna().sum()
    assert missing_count == 50

    metrics_data = json.loads(METRICS_PATH.read_text(encoding="utf-8"))
    assert metrics_data["dataset_records"] == 1000
    assert metrics_data["labeled_records"] == 950
    assert metrics_data["missing_label_records_excluded"] == 50


def test_models_evaluated_on_identical_holdout_rows():
    """Ensure all 3 candidate models are evaluated on the exact same 190 holdout samples."""
    df = pd.read_csv(DATA_PATH)
    df_clean = df[df["Loan_Approved"].notna()].copy()
    df_clean["target"] = df_clean["Loan_Approved"].str.strip().str.lower().map({"yes": 1, "no": 0})

    X = df_clean.drop(columns=["Loan_Approved", "Applicant_ID", "target"])
    y = df_clean["target"]

    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=0.20, random_state=42, stratify=y
    )

    assert len(X_test) == 190
    assert y_test.value_counts().to_dict() == {0: 130, 1: 60}

    # Verify predictions from all three saved pipelines on this exact test set
    for model_name in ["gradient_boosting", "random_forest", "logistic_regression"]:
        artifact_path = MODELS_DIR / f"{model_name}.joblib"
        assert artifact_path.exists()
        pipeline = joblib.load(artifact_path)
        probs = pipeline.predict_proba(X_test)[:, 1]
        assert len(probs) == 190
        assert np.all(np.isfinite(probs))
        assert np.all((probs >= 0.0) & (probs <= 1.0))


def test_confusion_matrices_internal_consistency():
    """Verify that confusion matrices sum to 190 and match holdout distributions."""
    cm_data = json.loads(CM_PATH.read_text(encoding="utf-8"))

    for key, item in cm_data.items():
        tn = item["true_negatives"]
        fp = item["false_positives"]
        fn = item["false_negatives"]
        tp = item["true_positives"]

        # Total test count must be 190
        assert tn + fp + fn + tp == 190
        assert item["sample_count"] == 190

        # Actual negatives = 130, actual positives = 60
        assert tn + fp == 130
        assert fn + tp == 60

        # Matrix structure check
        assert item["matrix"] == [[tn, fp], [fn, tp]]


def test_metrics_reproducibility_and_bounds():
    """Check that all recorded metrics are within [0, 1] and match evaluation calculations."""
    metrics_data = json.loads(METRICS_PATH.read_text(encoding="utf-8"))
    assert len(metrics_data["models"]) == 3

    for model in metrics_data["models"]:
        for metric_key in ["accuracy", "precision", "recall", "f1_score", "roc_auc"]:
            val = model[metric_key]
            assert 0.0 <= val <= 1.0, f"Metric {metric_key} out of range for {model['model_name']}"

        # Standard deviations must be positive and non-zero
        assert model["cv_std_accuracy"] > 0.0
        assert model["cv_std_roc_auc"] > 0.0


def test_gradient_boosting_matches_baseline_metrics():
    """Verify newly trained Gradient Boosting faithfully matches the reference baseline."""
    metrics_data = json.loads(METRICS_PATH.read_text(encoding="utf-8"))
    gb = next(m for m in metrics_data["models"] if m["model_key"] == "gradient_boosting")

    # Baseline reference: Accuracy ~95.8%, Precision ~90.6%, Recall ~96.7%, F1 ~93.5%, ROC-AUC ~98.8%
    assert abs(gb["accuracy"] - 0.9579) < 0.005
    assert abs(gb["precision"] - 0.9062) < 0.005
    assert abs(gb["recall"] - 0.9667) < 0.005
    assert abs(gb["f1_score"] - 0.9355) < 0.005
    assert abs(gb["roc_auc"] - 0.9877) < 0.005


def test_admin_model_comparison_api_endpoint(client, admin_user):
    """Admin endpoint /admin/model-comparison serves verified 3-model data."""
    response = client.get("/admin/model-comparison", headers=admin_user["headers"])
    assert response.status_code == 200
    data = response.json()
    assert len(data["models"]) == 3
    model_names = [m["model_name"] for m in data["models"]]
    assert "Gradient Boosting Classifier" in model_names
    assert "Random Forest Classifier" in model_names
    assert "Logistic Regression" in model_names


def test_admin_confusion_matrix_api_endpoint(client, admin_user):
    """Admin endpoint /admin/model-comparison/{model}/confusion-matrix serves matrix."""
    for model_name in ["gradient_boosting", "random_forest", "logistic_regression"]:
        response = client.get(
            f"/admin/model-comparison/{model_name}/confusion-matrix",
            headers=admin_user["headers"]
        )
        assert response.status_code == 200
        data = response.json()
        assert data["sample_count"] == 190
        assert data["true_negatives"] + data["false_positives"] + data["false_negatives"] + data["true_positives"] == 190


def test_admin_roc_curves_api_endpoint(client, admin_user):
    """Admin endpoint /admin/model-comparison/roc-curves serves ROC curves for all models."""
    response = client.get("/admin/model-comparison/roc-curves", headers=admin_user["headers"])
    assert response.status_code == 200
    data = response.json()
    assert "gradient_boosting" in data
    assert "random_forest" in data
    assert "logistic_regression" in data
    assert len(data["gradient_boosting"]["points"]) > 0
