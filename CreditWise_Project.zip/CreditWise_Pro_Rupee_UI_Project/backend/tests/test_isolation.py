"""Tests for multi-tenant customer isolation, role-based access control, and admin restrictions."""

import pytest


def test_customer_cannot_access_admin_endpoints(client, customer_user_1):
    """Customer account attempting to access /admin/overview receives 403 Forbidden."""
    response = client.get("/admin/overview", headers=customer_user_1["headers"])
    assert response.status_code == 403
    assert "Administrator access required" in response.json()["detail"]


def test_admin_can_access_admin_endpoints(client, admin_user):
    """Admin account accessing /admin/overview receives 200 OK."""
    response = client.get("/admin/overview", headers=admin_user["headers"])
    assert response.status_code == 200
    data = response.json()
    assert "total_users" in data
    assert "total_predictions" in data


def test_unauthenticated_request_rejected(client):
    """Endpoints requiring authentication return 401 when token is missing."""
    r1 = client.get("/auth/me")
    assert r1.status_code == 401

    r2 = client.get("/predictions/history")
    assert r2.status_code == 401

    r3 = client.get("/admin/overview")
    assert r3.status_code == 401


def test_registration_role_tampering_prevented(client):
    """Public registration cannot grant admin privileges even if role is injected in payload."""
    payload = {
        "email": "hacker@test.com",
        "password": "Password123!",
        "full_name": "Wannabe Admin",
        "role": "admin"  # Attempt to elevate role
    }
    response = client.post("/auth/register", json=payload)
    assert response.status_code == 201
    data = response.json()
    assert data["user"]["role"] == "customer"  # Must remain 'customer'


def test_strict_customer_prediction_history_isolation(
    client,
    customer_user_1,
    customer_user_2
):
    """
    Ensure Customer 2 CANNOT access Customer 1's prediction records.
    Prediction history must be strictly partitioned by authenticated user ID.
    """
    valid_payload = {
        "applicant_income_rupees": 1_000_000.0,
        "coapplicant_income_rupees": 300_000.0,
        "savings_rupees": 1_000_000.0,
        "collateral_value_rupees": 3_000_000.0,
        "loan_amount_lakh": 20.0,
        "employment_status": "Salaried",
        "age": 30.0,
        "marital_status": "Married",
        "dependents": 0.0,
        "credit_score": 700.0,
        "existing_loans": 1.0,
        "dti_ratio": 0.30,
        "loan_term": 36.0,
        "loan_purpose": "Personal",
        "property_area": "Urban",
        "education_level": "Graduate",
        "gender": "Male",
        "employer_category": "Private"
    }

    # Customer 1 creates a prediction
    pred_res_1 = client.post(
        "/predictions",
        json=valid_payload,
        headers=customer_user_1["headers"]
    )
    assert pred_res_1.status_code == 200
    created_id_1 = pred_res_1.json()["id"]

    # Customer 2 checks their own history
    hist_res_2 = client.get("/predictions/history", headers=customer_user_2["headers"])
    assert hist_res_2.status_code == 200
    history_2 = hist_res_2.json()

    # Customer 2 must NOT see Customer 1's prediction
    assert not any(item["id"] == created_id_1 for item in history_2)

    # Customer 1 checks their history and sees their prediction
    hist_res_1 = client.get("/predictions/history", headers=customer_user_1["headers"])
    assert hist_res_1.status_code == 200
    history_1 = hist_res_1.json()
    assert any(item["id"] == created_id_1 for item in history_1)
