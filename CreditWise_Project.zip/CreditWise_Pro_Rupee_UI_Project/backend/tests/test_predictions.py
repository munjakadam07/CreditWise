"""Tests for prediction execution, schema validation, and database cascading."""

import pytest
from backend.database import get_db, get_db_path


def test_health_check(client):
    """Health check endpoint returns 200 OK and model readiness."""
    response = client.get("/health")
    assert response.status_code == 200
    data = response.json()
    assert data["status"] == "healthy"
    assert data["model_loaded"] is True
    assert data["database"] == "connected"


def test_prediction_endpoint_success(client, customer_user_1):
    """Full prediction workflow returns approval probability, threshold, and label."""
    valid_payload = {
        "applicant_income_rupees": 1_000_000.0,
        "coapplicant_income_rupees": 300_000.0,
        "savings_rupees": 1_000_000.0,
        "collateral_value_rupees": 3_000_000.0,
        "loan_amount_lakh": 20.0,
        "employment_status": "Salaried",
        "age": 30.0,
        "marital_status": "Married",
        "dependents": 0.0,
        "credit_score": 700.0,
        "existing_loans": 1.0,
        "dti_ratio": 0.30,
        "loan_term": 36.0,
        "loan_purpose": "Personal",
        "property_area": "Urban",
        "education_level": "Graduate",
        "gender": "Male",
        "employer_category": "Private"
    }

    response = client.post(
        "/predictions",
        json=valid_payload,
        headers=customer_user_1["headers"]
    )
    assert response.status_code == 200
    data = response.json()

    assert "approval_probability" in data
    assert "rejection_probability" in data
    assert 0.0 <= data["approval_probability"] <= 1.0
    assert 0.0 <= data["rejection_probability"] <= 1.0
    assert abs(data["approval_probability"] + data["rejection_probability"] - 1.0) < 0.01
    assert data["decision_threshold"] == 0.50
    assert data["decision_label"] in ["Approved", "Rejected"]
    assert "top_factors" in data


def test_prediction_endpoint_ood_rejection(client, customer_user_1):
    """Out-of-distribution inputs are rejected with 422 and helpful violation detail."""
    ood_payload = {
        "applicant_income_rupees": 50_000_000.0,  # ₹5 Crore -> 500,000 units (> 19,988 max)
        "coapplicant_income_rupees": 300_000.0,
        "savings_rupees": 1_000_000.0,
        "collateral_value_rupees": 3_000_000.0,
        "loan_amount_lakh": 20.0,
        "employment_status": "Salaried",
        "age": 30.0,
        "marital_status": "Married",
        "dependents": 0.0,
        "credit_score": 700.0,
        "existing_loans": 1.0,
        "dti_ratio": 0.30,
        "loan_term": 36.0,
        "loan_purpose": "Personal",
        "property_area": "Urban",
        "education_level": "Graduate",
        "gender": "Male",
        "employer_category": "Private"
    }

    response = client.post(
        "/predictions",
        json=ood_payload,
        headers=customer_user_1["headers"]
    )
    assert response.status_code == 422
    data = response.json()
    assert "detail" in data
    assert "violations" in data["detail"]


def test_foreign_key_cascading_deletion(client, customer_user_1):
    """When a user is deleted, their predictions must be automatically cascaded and removed."""
    valid_payload = {
        "applicant_income_rupees": 1_000_000.0,
        "coapplicant_income_rupees": 300_000.0,
        "savings_rupees": 1_000_000.0,
        "collateral_value_rupees": 3_000_000.0,
        "loan_amount_lakh": 20.0,
        "employment_status": "Salaried",
        "age": 30.0,
        "marital_status": "Married",
        "dependents": 0.0,
        "credit_score": 700.0,
        "existing_loans": 1.0,
        "dti_ratio": 0.30,
        "loan_term": 36.0,
        "loan_purpose": "Personal",
        "property_area": "Urban",
        "education_level": "Graduate",
        "gender": "Male",
        "employer_category": "Private"
    }

    # Create prediction
    res = client.post(
        "/predictions",
        json=valid_payload,
        headers=customer_user_1["headers"]
    )
    assert res.status_code == 200
    pred_id = res.json()["id"]

    # Verify prediction exists in DB
    with get_db() as conn:
        cursor = conn.cursor()
        cursor.execute("SELECT id FROM predictions WHERE id = ?", (pred_id,))
        assert cursor.fetchone() is not None

        # Delete user
        cursor.execute("DELETE FROM users WHERE id = ?", (customer_user_1["id"],))

        # Check cascading deletion on predictions table
        cursor.execute("SELECT id FROM predictions WHERE id = ?", (pred_id,))
        assert cursor.fetchone() is None
