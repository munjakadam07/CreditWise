"""Pytest fixtures with isolated temporary test database and pre-authenticated clients."""

import os
import tempfile
from pathlib import Path
import pytest
from fastapi.testclient import TestClient

# Set test database path before importing app
temp_dir = tempfile.mkdtemp()
test_db_path = Path(temp_dir) / "test_creditwise.db"
os.environ["DATABASE_PATH"] = str(test_db_path)
os.environ["SECRET_KEY"] = "test_super_secret_jwt_key_for_unit_tests_32_chars_min"
os.environ["ACCESS_TOKEN_EXPIRE_MINUTES"] = "60"

from backend.auth import create_access_token, hash_password
from backend.database import get_db, init_db
from backend.main import app


@pytest.fixture(scope="session", autouse=True)
def setup_test_database():
    """Create fresh schema for the test session."""
    init_db(test_db_path)
    yield
    # Cleanup temporary test database file
    try:
        if test_db_path.exists():
            test_db_path.unlink()
    except Exception:
        pass


@pytest.fixture
def client():
    """Return FastAPI TestClient."""
    with TestClient(app) as test_client:
        yield test_client


@pytest.fixture
def customer_user_1():
    """Create and return customer 1 credentials and auth token."""
    email = "customer1@creditwise.local"
    raw_password = "SecurePassword123"
    full_name = "First Customer"

    with get_db(test_db_path) as conn:
        cursor = conn.cursor()
        cursor.execute("SELECT id FROM users WHERE email = ?", (email,))
        row = cursor.fetchone()
        if not row:
            hashed = hash_password(raw_password)
            cursor.execute(
                """
                INSERT INTO users (email, password_hash, full_name, role, is_active, created_at)
                VALUES (?, ?, ?, 'customer', 1, '2026-10-14T12:00:00Z')
                """,
                (email, hashed, full_name)
            )
            user_id = cursor.lastrowid
        else:
            user_id = row["id"]

    token = create_access_token(user_id=user_id, email=email, role="customer")
    return {
        "id": user_id,
        "email": email,
        "password": raw_password,
        "full_name": full_name,
        "token": token,
        "headers": {"Authorization": f"Bearer {token}"}
    }


@pytest.fixture
def customer_user_2():
    """Create and return customer 2 credentials and auth token."""
    email = "customer2@creditwise.local"
    raw_password = "AnotherPassword456"
    full_name = "Second Customer"

    with get_db(test_db_path) as conn:
        cursor = conn.cursor()
        cursor.execute("SELECT id FROM users WHERE email = ?", (email,))
        row = cursor.fetchone()
        if not row:
            hashed = hash_password(raw_password)
            cursor.execute(
                """
                INSERT INTO users (email, password_hash, full_name, role, is_active, created_at)
                VALUES (?, ?, ?, 'customer', 1, '2026-10-14T12:00:00Z')
                """,
                (email, hashed, full_name)
            )
            user_id = cursor.lastrowid
        else:
            user_id = row["id"]

    token = create_access_token(user_id=user_id, email=email, role="customer")
    return {
        "id": user_id,
        "email": email,
        "password": raw_password,
        "full_name": full_name,
        "token": token,
        "headers": {"Authorization": f"Bearer {token}"}
    }


@pytest.fixture
def admin_user():
    """Create and return admin credentials and auth token."""
    email = "admin@creditwise.local"
    raw_password = "AdminSuperSecret2026!"
    full_name = "Lead Administrator"

    with get_db(test_db_path) as conn:
        cursor = conn.cursor()
        cursor.execute("SELECT id FROM users WHERE email = ?", (email,))
        row = cursor.fetchone()
        if not row:
            hashed = hash_password(raw_password)
            cursor.execute(
                """
                INSERT INTO users (email, password_hash, full_name, role, is_active, created_at)
                VALUES (?, ?, ?, 'admin', 1, '2026-10-14T12:00:00Z')
                """,
                (email, hashed, full_name)
            )
            user_id = cursor.lastrowid
        else:
            user_id = row["id"]

    token = create_access_token(user_id=user_id, email=email, role="admin")
    return {
        "id": user_id,
        "email": email,
        "password": raw_password,
        "full_name": full_name,
        "token": token,
        "headers": {"Authorization": f"Bearer {token}"}
    }
