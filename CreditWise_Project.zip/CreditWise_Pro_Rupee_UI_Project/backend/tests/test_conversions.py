"""Unit tests for Indian Rupee/Lakh conversions and out-of-distribution range enforcement."""

import pytest
from backend.prediction_service import (
    convert_rupee_inputs_to_model_units,
    validate_training_ranges,
)
from backend.schemas import LoanPredictionRequest


def create_sample_request(**kwargs) -> LoanPredictionRequest:
    """Helper to generate a valid baseline prediction request."""
    defaults = {
        "applicant_income_rupees": 1_000_000.0,   # ₹10 Lakh -> 10,000.0 model units
        "coapplicant_income_rupees": 300_000.0,   # ₹3 Lakh -> 3,000.0 model units
        "savings_rupees": 1_000_000.0,             # ₹10 Lakh -> 10,000.0 model units
        "collateral_value_rupees": 3_000_000.0,   # ₹30 Lakh -> 30,000.0 model units
        "loan_amount_lakh": 20.0,                 # 20 Lakh -> 20,000.0 model units
        "employment_status": "Salaried",
        "age": 30.0,
        "marital_status": "Married",
        "dependents": 0.0,
        "credit_score": 700.0,
        "existing_loans": 1.0,
        "dti_ratio": 0.30,
        "loan_term": 36.0,
        "loan_purpose": "Personal",
        "property_area": "Urban",
        "education_level": "Graduate",
        "gender": "Male",
        "employer_category": "Private"
    }
    defaults.update(kwargs)
    return LoanPredictionRequest(**defaults)


def test_rupee_conversions_exact_math():
    """Verify exact Rupee and Lakh to model unit conversions."""
    req = create_sample_request()
    converted = convert_rupee_inputs_to_model_units(req)

    # ₹10,00,000 / 100.0 == 10,000.0
    assert converted["Applicant_Income"] == 10000.0
    # ₹3,00,000 / 100.0 == 3,000.0
    assert converted["Coapplicant_Income"] == 3000.0
    # ₹10,00,000 / 100.0 == 10,000.0
    assert converted["Savings"] == 10000.0
    # ₹30,00,000 / 100.0 == 30,000.0
    assert converted["Collateral_Value"] == 30000.0
    # 20.0 Lakh * 1000.0 == 20,000.0
    assert converted["Loan_Amount"] == 20000.0


def test_valid_inputs_pass_range_checks():
    """A standard realistic application must pass all range validations."""
    req = create_sample_request()
    converted = convert_rupee_inputs_to_model_units(req)
    violations = validate_training_ranges(converted)
    assert len(violations) == 0


def test_out_of_distribution_applicant_income_rejected():
    """Applicant income above the observed maximum (19,988 units = ₹19,98,800) is flagged."""
    # ₹35 Lakh -> 35,000 model units (max observed is 19,988)
    req = create_sample_request(applicant_income_rupees=3_500_000.0)
    converted = convert_rupee_inputs_to_model_units(req)
    violations = validate_training_ranges(converted)
    assert len(violations) > 0
    assert any("Applicant_Income" in v for v in violations)


def test_out_of_distribution_credit_score_rejected():
    """Credit score outside observed bounds [550, 799] is flagged."""
    # 850 exceeds max observed 799.0
    req = create_sample_request(credit_score=850.0)
    converted = convert_rupee_inputs_to_model_units(req)
    violations = validate_training_ranges(converted)
    assert len(violations) > 0
    assert any("Credit_Score" in v for v in violations)


def test_out_of_distribution_dti_ratio_rejected():
    """DTI ratio outside observed bounds [0.10, 0.60] is flagged."""
    req = create_sample_request(dti_ratio=0.75)
    converted = convert_rupee_inputs_to_model_units(req)
    violations = validate_training_ranges(converted)
    assert len(violations) > 0
    assert any("DTI_Ratio" in v for v in violations)
