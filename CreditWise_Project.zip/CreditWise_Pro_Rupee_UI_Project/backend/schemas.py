"""Pydantic schemas for request validation and response serialization."""

import re
from datetime import datetime
from typing import Any, Dict, List, Literal, Optional
from pydantic import BaseModel, ConfigDict, Field, field_validator

EMAIL_REGEX = re.compile(r"^[a-zA-Z0-9_.+-]+@[a-zA-Z0-9-]+\.[a-zA-Z0-9-.]+$")


# ==========================================
# Authentication Schemas
# ==========================================

class UserRegisterRequest(BaseModel):
    """Schema for customer registration."""
    email: str = Field(..., max_length=255, description="Valid email address")
    password: str = Field(..., min_length=8, max_length=128, description="Password must be at least 8 characters")
    full_name: str = Field(..., min_length=1, max_length=100)

    @field_validator("email")
    @classmethod
    def validate_email(cls, v: str) -> str:
        cleaned = v.strip().lower()
        if not EMAIL_REGEX.match(cleaned):
            raise ValueError("Invalid email format")
        return cleaned

    @field_validator("password")
    @classmethod
    def validate_password_complexity(cls, v: str) -> str:
        if not any(c.isalpha() for c in v):
            raise ValueError("Password must contain at least one letter")
        if not any(c.isdigit() for c in v):
            raise ValueError("Password must contain at least one digit")
        return v


class UserLoginRequest(BaseModel):
    """Schema for user login."""
    email: str = Field(..., max_length=255)
    password: str = Field(..., min_length=1)

    @field_validator("email")
    @classmethod
    def validate_email(cls, v: str) -> str:
        cleaned = v.strip().lower()
        if not EMAIL_REGEX.match(cleaned):
            raise ValueError("Invalid email format")
        return cleaned


class AdminLoginRequest(BaseModel):
    """Schema for administrator authentication via username or email."""
    username: str = Field(..., min_length=1, max_length=255, description="Administrator username or email")
    password: str = Field(..., min_length=1, max_length=128, description="Administrator password")


class UserProfileResponse(BaseModel):

    """Safe user profile response without password hashes."""
    id: int
    email: str
    full_name: str
    role: str
    created_at: str

    model_config = ConfigDict(from_attributes=True)


class TokenResponse(BaseModel):
    """JWT response after authentication."""
    access_token: str
    token_type: str = "bearer"
    user: UserProfileResponse


# ==========================================
# Prediction Schemas
# ==========================================

EmploymentStatusType = Literal["Salaried", "Self-employed", "Contract", "Unemployed"]
MaritalStatusType = Literal["Married", "Single"]
LoanPurposeType = Literal["Personal", "Car", "Business", "Home", "Education"]
PropertyAreaType = Literal["Urban", "Semiurban", "Rural"]
EducationLevelType = Literal["Graduate", "Not Graduate"]
GenderType = Literal["Male", "Female"]
EmployerCategoryType = Literal["Private", "Government", "MNC", "Business", "Unemployed"]


class LoanPredictionRequest(BaseModel):
    """Prediction request in user-facing Indian Rupee and standard units."""
    # Rupee / Lakh currency inputs
    applicant_income_rupees: float = Field(
        ...,
        description="Applicant annual income in Indian Rupees (₹)",
        ge=0.0
    )
    coapplicant_income_rupees: float = Field(
        ...,
        description="Coapplicant annual income in Indian Rupees (₹)",
        ge=0.0
    )
    savings_rupees: float = Field(
        ...,
        description="Total savings in Indian Rupees (₹)",
        ge=0.0
    )
    collateral_value_rupees: float = Field(
        ...,
        description="Collateral asset value in Indian Rupees (₹)",
        ge=0.0
    )
    loan_amount_lakh: float = Field(
        ...,
        description="Requested loan amount in Lakhs (₹ lakh)",
        ge=0.1
    )

    # Demographics and credit features
    age: float = Field(..., ge=18.0, le=100.0)
    dependents: float = Field(..., ge=0.0, le=20.0)
    credit_score: float = Field(..., ge=300.0, le=900.0)
    existing_loans: float = Field(..., ge=0.0, le=20.0)
    dti_ratio: float = Field(..., ge=0.0, le=1.0, description="Debt-to-Income ratio (0.0 to 1.0)")
    loan_term: float = Field(..., ge=6.0, le=360.0, description="Loan term in months")

    # Categorical features
    employment_status: EmploymentStatusType
    marital_status: MaritalStatusType
    loan_purpose: LoanPurposeType
    property_area: PropertyAreaType
    education_level: EducationLevelType
    gender: GenderType
    employer_category: EmployerCategoryType


class LoanPredictionResponse(BaseModel):
    """Detailed loan prediction result."""
    id: Optional[int] = None
    approval_probability: float
    rejection_probability: float
    decision_threshold: float
    prediction: int  # 1 for Approved, 0 for Rejected
    decision_label: str  # "Approved" or "Rejected"
    model_version: str
    created_at: str
    warnings: List[str] = []
    top_factors: Optional[List[Dict[str, Any]]] = None


class PredictionHistoryItem(BaseModel):
    """Historical prediction item for customer or admin audit."""
    id: int
    user_id: int
    created_at: str
    applicant_income_rupees: float
    coapplicant_income_rupees: float
    savings_rupees: float
    collateral_value_rupees: float
    loan_amount_lakh: float
    employment_status: str
    age: float
    marital_status: str
    dependents: float
    credit_score: float
    existing_loans: float
    dti_ratio: float
    loan_term: float
    loan_purpose: str
    property_area: str
    education_level: str
    gender: str
    employer_category: str
    approval_probability: float
    rejection_probability: float
    decision_threshold: float
    prediction: int
    decision_label: str
    model_version: str

    model_config = ConfigDict(from_attributes=True)


# ==========================================
# Admin Schemas
# ==========================================

class AdminOverviewResponse(BaseModel):
    """Overview statistics for administrative dashboard."""
    total_users: int
    total_customers: int
    total_predictions: int
    approved_predictions: int
    rejected_predictions: int
    overall_approval_rate: float
    average_approval_probability: float
    active_model: str


class ConfusionMatrixItem(BaseModel):
    """Confusion matrix data points."""
    true_label: int
    predicted_label: int
    count: int


class ModelMetricDetail(BaseModel):
    """Detailed verified model metrics."""
    model_name: str
    accuracy: float
    precision: float
    recall: float
    f1_score: float
    roc_auc: float
    cv_mean_roc_auc: Optional[float] = None
    cv_mean_accuracy: Optional[float] = None
    description: str


class ModelComparisonResponse(BaseModel):
    """Comparison payload of all evaluated models."""
    evaluation_date: str
    dataset_records: int
    labeled_records: int
    missing_label_records_excluded: int
    models: List[ModelMetricDetail]
