"""Prediction service handling Rupee conversions, OOD range validation, and ML inference."""

import json
import os
from pathlib import Path
from typing import Any, Dict, List, Tuple
import joblib
import pandas as pd
from fastapi import HTTPException, status

from backend.schemas import LoanPredictionRequest

# Paths
ROOT_DIR = Path(__file__).resolve().parent.parent
MODEL_PATH = Path(os.getenv("MODEL_PATH", ROOT_DIR / "creditwise_model.joblib"))
FEATURE_RANGES_PATH = Path(os.getenv("FEATURE_RANGES_PATH", ROOT_DIR / "data" / "feature_ranges.json"))

_cached_model = None
_cached_ranges = None


def load_feature_ranges() -> Dict[str, Dict[str, float]]:
    """Load observed training ranges for OOD safety."""
    global _cached_ranges
    if _cached_ranges is None:
        if not FEATURE_RANGES_PATH.exists():
            # Fallback to root feature_ranges.json if data/ not populated yet
            alt_path = ROOT_DIR / "feature_ranges.json"
            if alt_path.exists():
                _cached_ranges = json.loads(alt_path.read_text(encoding="utf-8"))
            else:
                raise FileNotFoundError(f"Feature ranges file not found at {FEATURE_RANGES_PATH} or {alt_path}")
        else:
            _cached_ranges = json.loads(FEATURE_RANGES_PATH.read_text(encoding="utf-8"))
    return _cached_ranges


def get_loaded_model():
    """Load and cache the trained Scikit-learn pipeline."""
    global _cached_model
    if _cached_model is None:
        if not MODEL_PATH.exists():
            raise FileNotFoundError(f"Trained model artifact not found at {MODEL_PATH}")
        _cached_model = joblib.load(MODEL_PATH)
    return _cached_model


def convert_rupee_inputs_to_model_units(req: LoanPredictionRequest) -> Dict[str, Any]:
    """
    Convert user-facing Rupee and Lakh inputs to model feature units.
    Conversion formula established in the original CreditWise implementation:
      - Applicant Income: Rupee / 100.0
      - Coapplicant Income: Rupee / 100.0
      - Savings: Rupee / 100.0
      - Collateral Value: Rupee / 100.0
      - Loan Amount: Lakh * 1000.0 (equivalent to Rupee / 100.0)
    """
    return {
        "Applicant_Income": round(req.applicant_income_rupees / 100.0, 2),
        "Coapplicant_Income": round(req.coapplicant_income_rupees / 100.0, 2),
        "Savings": round(req.savings_rupees / 100.0, 2),
        "Collateral_Value": round(req.collateral_value_rupees / 100.0, 2),
        "Loan_Amount": round(req.loan_amount_lakh * 1000.0, 2),
        "Employment_Status": req.employment_status,
        "Age": req.age,
        "Marital_Status": req.marital_status,
        "Dependents": req.dependents,
        "Credit_Score": req.credit_score,
        "Existing_Loans": req.existing_loans,
        "DTI_Ratio": req.dti_ratio,
        "Loan_Term": req.loan_term,
        "Loan_Purpose": req.loan_purpose,
        "Property_Area": req.property_area,
        "Education_Level": req.education_level,
        "Gender": req.gender,
        "Employer_Category": req.employer_category,
    }


def validate_training_ranges(model_row: Dict[str, Any]) -> List[str]:
    """
    Ensure input values do not fall outside the observed training data bounds.
    Matches app.py logic to prevent uncontrolled out-of-distribution extrapolation.
    """
    ranges = load_feature_ranges()
    violations: List[str] = []

    for feature_name, bounds in ranges.items():
        if feature_name == "Loan_Amount":
            # Form restricts loan amount between 1 and 40 Lakh (1,000 to 40,000 in model units)
            continue
        val = float(model_row.get(feature_name, 0.0))
        min_val = bounds["min"]
        max_val = bounds["max"]
        if val < min_val or val > max_val:
            violations.append(
                f"{feature_name}: {val} is outside observed range [{min_val}, {max_val}]"
            )

    return violations


def explain_prediction(model) -> List[Dict[str, Any]]:
    """Extract top overall feature importances from the pipeline."""
    try:
        pre = model.named_steps["preprocessor"]
        clf = model.named_steps["model"]
        feature_names = pre.get_feature_names_out()
        importances = clf.feature_importances_

        factors = []
        for name, imp in zip(feature_names, importances):
            clean_name = (
                name.replace("num__", "")
                .replace("cat__", "")
                .replace("numeric__", "")
                .replace("categorical__", "")
            )
            factors.append({"feature": clean_name, "importance": round(float(imp), 4)})

        factors.sort(key=lambda x: x["importance"], reverse=True)
        return factors[:10]
    except Exception:
        return []


def predict_loan(req: LoanPredictionRequest) -> Tuple[Dict[str, Any], Dict[str, Any]]:
    """
    Perform full loan prediction workflow:
      1. Conversion from Rupees/Lakh to model units.
      2. OOD range validation.
      3. Inference through Scikit-learn Pipeline.
      4. Decision determination at 0.50 threshold.
    Returns: (prediction_result, model_units_dict)
    """
    model_row = convert_rupee_inputs_to_model_units(req)
    violations = validate_training_ranges(model_row)

    if violations:
        raise HTTPException(
            status_code=422,
            detail={
                "message": "Application values fall outside observed training data distribution. Prediction blocked to prevent unreliable extrapolation.",
                "violations": violations
            }
        )

    model = get_loaded_model()
    input_df = pd.DataFrame([model_row])

    try:
        prob_approved = float(model.predict_proba(input_df)[0, 1])
    except Exception as exc:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Inference failure: {str(exc)}"
        )

    prob_rejected = round(1.0 - prob_approved, 4)
    prob_approved = round(prob_approved, 4)
    threshold = 0.50
    decision = 1 if prob_approved >= threshold else 0
    decision_label = "Approved" if decision == 1 else "Rejected"

    top_factors = explain_prediction(model)

    result = {
        "approval_probability": prob_approved,
        "rejection_probability": prob_rejected,
        "decision_threshold": threshold,
        "prediction": decision,
        "decision_label": decision_label,
        "model_version": "GradientBoostingClassifier-v1.0",
        "top_factors": top_factors,
    }

    return result, model_row
