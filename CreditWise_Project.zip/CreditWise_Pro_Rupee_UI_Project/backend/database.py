"""Database access and schema management for CreditWise."""

import os
import sqlite3
from contextlib import contextmanager
from pathlib import Path
from typing import Generator, Optional

DEFAULT_DB_PATH = Path(__file__).resolve().parent.parent / "creditwise_app.db"


def get_db_path() -> Path:
    """Return database file path from environment or default."""
    configured = os.getenv("DATABASE_PATH")
    if configured:
        return Path(configured)
    return DEFAULT_DB_PATH


def create_connection(db_path: Optional[Path] = None) -> sqlite3.Connection:
    """Create a SQLite connection with foreign keys enabled and dict-like row access."""
    path = db_path or get_db_path()
    # Ensure parent directory exists
    path.parent.mkdir(parents=True, exist_ok=True)
    conn = sqlite3.connect(str(path), check_same_thread=False)
    conn.execute("PRAGMA foreign_keys = ON;")
    conn.execute("PRAGMA journal_mode = WAL;")
    conn.row_factory = sqlite3.Row
    return conn


@contextmanager
def get_db(db_path: Optional[Path] = None) -> Generator[sqlite3.Connection, None, None]:
    """Yield a database connection wrapped in a transaction."""
    conn = create_connection(db_path)
    try:
        yield conn
        conn.commit()
    except Exception:
        conn.rollback()
        raise
    finally:
        conn.close()


def init_db(db_path: Optional[Path] = None) -> None:
    """Initialize database tables, foreign keys, and indexes."""
    with get_db(db_path) as conn:
        conn.execute("""
        CREATE TABLE IF NOT EXISTS users (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            email TEXT UNIQUE NOT NULL COLLATE NOCASE,
            password_hash TEXT NOT NULL,
            full_name TEXT NOT NULL,
            role TEXT NOT NULL DEFAULT 'customer' CHECK(role IN ('customer', 'admin')),
            is_active INTEGER NOT NULL DEFAULT 1,
            created_at TEXT NOT NULL
        );
        """)

        conn.execute("""
        CREATE INDEX IF NOT EXISTS idx_users_email ON users(email);
        """)

        conn.execute("""
        CREATE TABLE IF NOT EXISTS predictions (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
            created_at TEXT NOT NULL,
            applicant_income_rupees REAL NOT NULL,
            coapplicant_income_rupees REAL NOT NULL,
            savings_rupees REAL NOT NULL,
            collateral_value_rupees REAL NOT NULL,
            loan_amount_lakh REAL NOT NULL,
            employment_status TEXT NOT NULL,
            age REAL NOT NULL,
            marital_status TEXT NOT NULL,
            dependents REAL NOT NULL,
            credit_score REAL NOT NULL,
            existing_loans REAL NOT NULL,
            dti_ratio REAL NOT NULL,
            loan_term REAL NOT NULL,
            loan_purpose TEXT NOT NULL,
            property_area TEXT NOT NULL,
            education_level TEXT NOT NULL,
            gender TEXT NOT NULL,
            employer_category TEXT NOT NULL,
            applicant_income_model REAL NOT NULL,
            coapplicant_income_model REAL NOT NULL,
            savings_model REAL NOT NULL,
            collateral_value_model REAL NOT NULL,
            loan_amount_model REAL NOT NULL,
            approval_probability REAL NOT NULL,
            rejection_probability REAL NOT NULL,
            decision_threshold REAL NOT NULL DEFAULT 0.50,
            prediction INTEGER NOT NULL CHECK(prediction IN (0, 1)),
            decision_label TEXT NOT NULL,
            model_version TEXT NOT NULL
        );
        """)

        conn.execute("""
        CREATE INDEX IF NOT EXISTS idx_predictions_user_id ON predictions(user_id);
        """)
        conn.execute("""
        CREATE INDEX IF NOT EXISTS idx_predictions_created_at ON predictions(created_at);
        """)
