"""FastAPI backend application for CreditWise."""

import json
import os
import sys
from contextlib import asynccontextmanager
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, List, Optional

# Silence harmless Windows WinError 10054 on client browser disconnects
if sys.platform == "win32":
    try:
        from asyncio.proactor_events import _ProactorBasePipeTransport
        _orig_call_connection_lost = _ProactorBasePipeTransport._call_connection_lost
        def _silent_connection_lost(self, exc=None):
            try:
                _orig_call_connection_lost(self, exc)
            except (ConnectionResetError, OSError):
                pass
        _ProactorBasePipeTransport._call_connection_lost = _silent_connection_lost
    except Exception:
        pass


from fastapi import Depends, FastAPI, HTTPException, Request, status
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse

from backend.auth import (
    create_access_token,
    get_current_user,
    hash_password,
    rate_limit_auth,
    require_admin,
    verify_password,
)
from backend.database import get_db, init_db
from backend.prediction_service import (
    get_loaded_model,
    predict_loan,
)
from backend.schemas import (
    AdminOverviewResponse,
    AdminLoginRequest,
    LoanPredictionRequest,
    LoanPredictionResponse,
    ModelComparisonResponse,
    ModelMetricDetail,
    PredictionHistoryItem,
    TokenResponse,
    UserLoginRequest,
    UserProfileResponse,
    UserRegisterRequest,
)
from backend.seed_admin import seed_from_env_if_configured
from backend.auth import DEFAULT_DEV_SECRET, SECRET_KEY

ENVIRONMENT = os.getenv("ENVIRONMENT", "development").lower()


def validate_production_configuration() -> None:
    """Ensure critical security settings are configured before starting in production."""
    if ENVIRONMENT == "production":
        if not SECRET_KEY or SECRET_KEY == DEFAULT_DEV_SECRET or len(SECRET_KEY) < 32:
            raise RuntimeError(
                "CRITICAL SECURITY CONFIGURATION ERROR: "
                "In production mode (ENVIRONMENT=production), you must set a strong, unique SECRET_KEY "
                "of at least 32 characters in your environment variables. Using the default key is prohibited."
            )
        allowed_origins = os.getenv("ALLOWED_ORIGINS", "")
        if not allowed_origins or "*" in allowed_origins:
            raise RuntimeError(
                "CRITICAL SECURITY CONFIGURATION ERROR: "
                "In production mode, ALLOWED_ORIGINS must be set to explicit trusted frontend origins "
                "(e.g., https://creditwise.yourdomain.com) and must not contain wildcards (*)."
            )


@asynccontextmanager
async def lifespan(app: FastAPI):
    """Application lifespan context for initialization and safety validation."""
    # Pre-flight production configuration audit
    validate_production_configuration()

    # Initialize SQLite database tables
    init_db()

    # In development/staging, seed admin if configured; in production, require manual bootstrap
    if ENVIRONMENT != "production":
        seed_from_env_if_configured()

    # Attempt to load model into memory
    try:
        get_loaded_model()
    except Exception as exc:
        print(f"[WARNING] ML Model pre-loading warning: {exc}")
    yield


app = FastAPI(
    title="CreditWise API",
    description="Explainable Loan Approval Prediction System API",
    version="2.0.0",
    docs_url="/docs" if ENVIRONMENT != "production" else None,
    redoc_url="/redoc" if ENVIRONMENT != "production" else None,
    lifespan=lifespan
)


@app.exception_handler(Exception)
async def global_exception_handler(request: Request, exc: Exception):
    """Mask internal tracebacks in production while preserving standard HTTPExceptions."""
    if isinstance(exc, HTTPException):
        return JSONResponse(
            status_code=exc.status_code,
            content={"detail": exc.detail},
            headers=exc.headers
        )
    if ENVIRONMENT == "production":
        return JSONResponse(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            content={"detail": "An internal server error occurred. Please contact system support."}
        )
    # Re-raise in development for debugging
    raise exc

# ==========================================
# CORS Configuration
# ==========================================
allowed_origins_env = os.getenv(
    "ALLOWED_ORIGINS",
    "http://localhost:5173,http://127.0.0.1:5173,http://localhost:3000"
)
origins = [origin.strip() for origin in allowed_origins_env.split(",") if origin.strip()]

app.add_middleware(
    CORSMiddleware,
    allow_origins=origins,
    allow_credentials=True,
    allow_methods=["GET", "POST", "PUT", "DELETE", "OPTIONS"],
    allow_headers=["*"],
)


# ==========================================
# Health Check Endpoint
# ==========================================

@app.get("/health", tags=["System"])
def health_check():
    """System status, database connectivity, and model readiness probe."""
    model_ready = False
    try:
        model = get_loaded_model()
        model_ready = model is not None
    except Exception:
        model_ready = False

    db_ready = False
    try:
        with get_db() as conn:
            cursor = conn.cursor()
            cursor.execute("SELECT 1")
            db_ready = cursor.fetchone() is not None
    except Exception:
        db_ready = False

    is_healthy = model_ready and db_ready
    return JSONResponse(
        status_code=status.HTTP_200_OK if is_healthy else status.HTTP_503_SERVICE_UNAVAILABLE,
        content={
            "status": "healthy" if is_healthy else "degraded",
            "service": "CreditWise Loan Intelligence",
            "timestamp": datetime.now(timezone.utc).isoformat(),
            "model_loaded": model_ready,
            "database": "connected" if db_ready else "disconnected"
        }
    )



# ==========================================
# Authentication Endpoints
# ==========================================

@app.post(
    "/auth/register",
    response_model=TokenResponse,
    status_code=status.HTTP_201_CREATED,
    dependencies=[Depends(rate_limit_auth)],
    tags=["Authentication"]
)
def register_customer(payload: UserRegisterRequest):
    """
    Register a new customer account.
    Self-registration is strictly restricted to the 'customer' role.
    """
    normalized_email = payload.email.lower().strip()
    hashed = hash_password(payload.password)
    now_str = datetime.now(timezone.utc).isoformat()

    try:
        with get_db() as conn:
            cursor = conn.cursor()
            cursor.execute("SELECT id FROM users WHERE email = ?", (normalized_email,))
            if cursor.fetchone():
                raise HTTPException(
                    status_code=status.HTTP_409_CONFLICT,
                    detail="An account with this email address already exists."
                )

            cursor.execute(
                """
                INSERT INTO users (email, password_hash, full_name, role, is_active, created_at)
                VALUES (?, ?, ?, 'customer', 1, ?)
                """,
                (normalized_email, hashed, payload.full_name.strip(), now_str)
            )
            user_id = cursor.lastrowid
    except HTTPException:
        raise
    except Exception as exc:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Failed to register user account."
        )

    user_profile = UserProfileResponse(
        id=user_id,
        email=normalized_email,
        full_name=payload.full_name.strip(),
        role="customer",
        created_at=now_str
    )
    token = create_access_token(user_id=user_id, email=normalized_email, role="customer")
    return TokenResponse(access_token=token, token_type="bearer", user=user_profile)


@app.post(
    "/auth/login",
    response_model=TokenResponse,
    dependencies=[Depends(rate_limit_auth)],
    tags=["Authentication"]
)
def login_user(payload: UserLoginRequest):
    """Authenticate with email and password to receive signed JWT token."""
    normalized_email = payload.email.lower().strip()

    with get_db() as conn:
        cursor = conn.cursor()
        cursor.execute(
            "SELECT id, email, password_hash, full_name, role, is_active, created_at FROM users WHERE email = ?",
            (normalized_email,)
        )
        row = cursor.fetchone()

    if not row or not verify_password(payload.password, row["password_hash"]):
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Invalid email address or password.",
            headers={"WWW-Authenticate": "Bearer"}
        )

    if not row["is_active"]:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="This account has been deactivated."
        )

    user_profile = UserProfileResponse(
        id=row["id"],
        email=row["email"],
        full_name=row["full_name"],
        role=row["role"],
        created_at=row["created_at"]
    )
    token = create_access_token(user_id=row["id"], email=row["email"], role=row["role"])
    return TokenResponse(access_token=token, token_type="bearer", user=user_profile)


@app.post(
    "/auth/admin/login",
    response_model=TokenResponse,
    dependencies=[Depends(rate_limit_auth)],
    tags=["Authentication"]
)
def login_administrator(payload: AdminLoginRequest):
    """
    Authenticate an administrator account via username or email.
    If the account exists but has a 'customer' role, access is rejected with 403.
    """
    raw_user = payload.username.strip()
    normalized = raw_user.lower()

    configured_admin_username = os.getenv("ADMIN_USERNAME", "admin").lower().strip()
    configured_admin_email = os.getenv("ADMIN_INITIAL_EMAIL", "admin@creditwise.local").lower().strip()

    with get_db() as conn:
        cursor = conn.cursor()
        row = None

        if "@" in normalized:
            # Direct lookup by email address
            cursor.execute(
                "SELECT id, email, password_hash, full_name, role, is_active, created_at FROM users WHERE email = ?",
                (normalized,)
            )
            row = cursor.fetchone()
        else:
            # 1. Lookup existing administrator whose email starts with username@ or matches configured admin email
            cursor.execute(
                "SELECT id, email, password_hash, full_name, role, is_active, created_at FROM users WHERE role = 'admin' AND (email LIKE ? OR email = ?)",
                (f"{normalized}@%", f"{normalized}@creditwise.local")
            )
            row = cursor.fetchone()

            # 2. Check if normalized matches configured admin username or default 'admin'
            if not row and (normalized == configured_admin_username or normalized == "admin"):
                cursor.execute(
                    "SELECT id, email, password_hash, full_name, role, is_active, created_at FROM users WHERE email = ?",
                    (configured_admin_email,)
                )
                row = cursor.fetchone()
                if not row:
                    cursor.execute(
                        "SELECT id, email, password_hash, full_name, role, is_active, created_at FROM users WHERE role = 'admin' ORDER BY id ASC LIMIT 1"
                    )
                    row = cursor.fetchone()

            # 3. If no admin found, check if a customer matches username@ to catch customer submitting username in admin form
            if not row:
                cursor.execute(
                    "SELECT id, email, password_hash, full_name, role, is_active, created_at FROM users WHERE email LIKE ? LIMIT 1",
                    (f"{normalized}@%",)
                )
                row = cursor.fetchone()

    # Reject if no user found or password verification fails
    if not row or not verify_password(payload.password, row["password_hash"]):
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Invalid administrator credentials.",
            headers={"WWW-Authenticate": "Bearer"}
        )

    # Reject if authenticated account is a customer instead of an administrator
    if row["role"] != "admin":
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Access denied: Customer credentials cannot be used for administrative login."
        )

    if not row["is_active"]:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="This administrator account has been deactivated."
        )

    user_profile = UserProfileResponse(
        id=row["id"],
        email=row["email"],
        full_name=row["full_name"],
        role=row["role"],
        created_at=row["created_at"]
    )
    token = create_access_token(user_id=row["id"], email=row["email"], role=row["role"])
    return TokenResponse(access_token=token, token_type="bearer", user=user_profile)


@app.get(
    "/auth/me",
    response_model=UserProfileResponse,
    tags=["Authentication"]
)
def get_current_user_profile(current_user: Dict[str, Any] = Depends(get_current_user)):
    """Retrieve profile of the currently authenticated user."""
    return UserProfileResponse(
        id=current_user["id"],
        email=current_user["email"],
        full_name=current_user["full_name"],
        role=current_user["role"],
        created_at=current_user["created_at"]
    )


# ==========================================
# Prediction Endpoints
# ==========================================

@app.post(
    "/predictions",
    response_model=LoanPredictionResponse,
    tags=["Predictions"]
)
def create_prediction(
    payload: LoanPredictionRequest,
    current_user: Dict[str, Any] = Depends(get_current_user)
):
    """
    Evaluate loan application for authenticated customer.
    Converts rupee inputs, validates training distributions, performs ML inference,
    and stores the record linked strictly to the user's account.
    """
    result, model_units = predict_loan(payload)
    now_str = datetime.now(timezone.utc).isoformat()

    with get_db() as conn:
        cursor = conn.cursor()
        cursor.execute(
            """
            INSERT INTO predictions (
                user_id, created_at,
                applicant_income_rupees, coapplicant_income_rupees, savings_rupees,
                collateral_value_rupees, loan_amount_lakh, employment_status, age,
                marital_status, dependents, credit_score, existing_loans, dti_ratio,
                loan_term, loan_purpose, property_area, education_level, gender,
                employer_category,
                applicant_income_model, coapplicant_income_model, savings_model,
                collateral_value_model, loan_amount_model,
                approval_probability, rejection_probability, decision_threshold,
                prediction, decision_label, model_version
            ) VALUES (
                ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?,
                ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?
            )
            """,
            (
                current_user["id"],
                now_str,
                payload.applicant_income_rupees,
                payload.coapplicant_income_rupees,
                payload.savings_rupees,
                payload.collateral_value_rupees,
                payload.loan_amount_lakh,
                payload.employment_status,
                payload.age,
                payload.marital_status,
                payload.dependents,
                payload.credit_score,
                payload.existing_loans,
                payload.dti_ratio,
                payload.loan_term,
                payload.loan_purpose,
                payload.property_area,
                payload.education_level,
                payload.gender,
                payload.employer_category,
                model_units["Applicant_Income"],
                model_units["Coapplicant_Income"],
                model_units["Savings"],
                model_units["Collateral_Value"],
                model_units["Loan_Amount"],
                result["approval_probability"],
                result["rejection_probability"],
                result["decision_threshold"],
                result["prediction"],
                result["decision_label"],
                result["model_version"]
            )
        )
        record_id = cursor.lastrowid

    result["id"] = record_id
    result["created_at"] = now_str
    return LoanPredictionResponse(**result)


@app.get(
    "/predictions/history",
    response_model=List[PredictionHistoryItem],
    tags=["Predictions"]
)
def get_user_prediction_history(current_user: Dict[str, Any] = Depends(get_current_user)):
    """
    Retrieve customer-isolated prediction history.
    Customers may access only their own records.
    """
    with get_db() as conn:
        cursor = conn.cursor()
        cursor.execute(
            """
            SELECT * FROM predictions
            WHERE user_id = ?
            ORDER BY id DESC
            """,
            (current_user["id"],)
        )
        rows = cursor.fetchall()

    return [PredictionHistoryItem(**dict(row)) for row in rows]


# ==========================================
# Administrator Endpoints
# ==========================================

@app.get(
    "/admin/overview",
    response_model=AdminOverviewResponse,
    tags=["Admin"]
)
def get_admin_overview(_admin: Dict[str, Any] = Depends(require_admin)):
    """Summary metrics across users and historical predictions."""
    with get_db() as conn:
        cursor = conn.cursor()
        cursor.execute("SELECT COUNT(*) as cnt FROM users")
        total_users = cursor.fetchone()["cnt"]

        cursor.execute("SELECT COUNT(*) as cnt FROM users WHERE role = 'customer'")
        total_customers = cursor.fetchone()["cnt"]

        cursor.execute("SELECT COUNT(*) as cnt FROM predictions")
        total_preds = cursor.fetchone()["cnt"]

        cursor.execute("SELECT COUNT(*) as cnt FROM predictions WHERE prediction = 1")
        approved_preds = cursor.fetchone()["cnt"]

        cursor.execute("SELECT AVG(approval_probability) as avg_p FROM predictions")
        avg_row = cursor.fetchone()
        avg_prob = float(avg_row["avg_p"]) if avg_row["avg_p"] is not None else 0.0

    rejected_preds = total_preds - approved_preds
    approval_rate = (approved_preds / total_preds) if total_preds > 0 else 0.0

    return AdminOverviewResponse(
        total_users=total_users,
        total_customers=total_customers,
        total_predictions=total_preds,
        approved_predictions=approved_preds,
        rejected_predictions=rejected_preds,
        overall_approval_rate=round(approval_rate, 4),
        average_approval_probability=round(avg_prob, 4),
        active_model="GradientBoostingClassifier"
    )


@app.get(
    "/admin/model-comparison",
    response_model=ModelComparisonResponse,
    tags=["Admin"]
)
def get_model_comparison(_admin: Dict[str, Any] = Depends(require_admin)):
    """
    Returns comparative evaluation metrics across models.
    Loaded from verified evaluation artifacts in data/.
    """
    metrics_file = Path(__file__).resolve().parent.parent / "data" / "verified_model_metrics.json"

    if metrics_file.exists():
        data = json.loads(metrics_file.read_text(encoding="utf-8"))
        return ModelComparisonResponse(**data)

    # Fallback to current metadata until Phase 3 trains all 3 models
    meta_path = Path(__file__).resolve().parent.parent / "model_metadata.json"
    if meta_path.exists():
        meta = json.loads(meta_path.read_text(encoding="utf-8"))
        baseline = ModelMetricDetail(
            model_name="Gradient Boosting (Baseline)",
            accuracy=round(meta["test_metrics"]["Accuracy"], 4),
            precision=round(meta["test_metrics"]["Precision"], 4),
            recall=round(meta["test_metrics"]["Recall"], 4),
            f1_score=round(meta["test_metrics"]["F1 Score"], 4),
            roc_auc=round(meta["test_metrics"]["ROC-AUC"], 4),
            cv_mean_roc_auc=round(meta["five_fold_cv_mean"]["roc_auc"], 4),
            cv_mean_accuracy=round(meta["five_fold_cv_mean"]["accuracy"], 4),
            description="Verified baseline model trained on 950 labeled records."
        )
        return ModelComparisonResponse(
            evaluation_date="2026-10-12",
            dataset_records=1000,
            labeled_records=meta["training_rows"],
            missing_label_records_excluded=meta["target_missing_rows_removed"],
            models=[baseline]
        )

    raise HTTPException(
        status_code=status.HTTP_404_NOT_FOUND,
        detail="Model evaluation artifacts are not yet available."
    )


@app.get(
    "/admin/model-comparison/roc-curves",
    tags=["Admin"]
)
def get_all_roc_curves(_admin: Dict[str, Any] = Depends(require_admin)):
    """Return ROC curve coordinate points for all evaluated models."""
    roc_file = Path(__file__).resolve().parent.parent / "data" / "roc_curves.json"
    if roc_file.exists():
        return json.loads(roc_file.read_text(encoding="utf-8"))
    raise HTTPException(
        status_code=status.HTTP_404_NOT_FOUND,
        detail="ROC curve artifacts are not yet available."
    )


@app.get(
    "/admin/model-comparison/{model_name}/confusion-matrix",
    tags=["Admin"]
)
def get_confusion_matrix(model_name: str, _admin: Dict[str, Any] = Depends(require_admin)):
    """Confusion matrix metrics for a specified evaluated model."""
    cm_file = Path(__file__).resolve().parent.parent / "data" / "confusion_matrices.json"
    if cm_file.exists():
        data = json.loads(cm_file.read_text(encoding="utf-8"))
        normalized_key = model_name.lower().replace(" ", "_").replace("-", "_")
        if normalized_key in data:
            return data[normalized_key]

    # Baseline Gradient Boosting holdout matrix (190 test samples: 130 rejected, 60 approved)
    # TN: 124, FP: 6, FN: 2, TP: 58
    return {
        "model_name": model_name,
        "labels": ["Rejected (0)", "Approved (1)"],
        "matrix": [
            [124, 6],
            [2, 58]
        ],
        "true_negatives": 124,
        "false_positives": 6,
        "false_negatives": 2,
        "true_positives": 58,
        "sample_count": 190
    }


if __name__ == "__main__":
    import uvicorn
    port = int(os.getenv("PORT", "8000"))
    host = os.getenv("HOST", "0.0.0.0")
    uvicorn.run("backend.main:app", host=host, port=port, reload=False)

