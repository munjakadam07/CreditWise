"""Administrative account provisioning utility.

Usage:
    python -m backend.seed_admin [--email admin@example.com] [--name "System Admin"] [--password <secret>]

Or set ADMIN_INITIAL_EMAIL and ADMIN_INITIAL_PASSWORD in .env.
Passwords and tokens are NEVER printed or logged.
"""

import argparse
import os
import sys
from datetime import datetime, timezone
from pathlib import Path

from backend.auth import hash_password
from backend.database import get_db, init_db


def seed_administrator(
    email: str,
    password: str,
    full_name: str = "System Administrator"
) -> bool:
    """Create or verify existence of the administrative account."""
    if not email or not password:
        print("[ERROR] Email and password are required to provision an admin account.", file=sys.stderr)
        return False

    if len(password) < 8:
        print("[ERROR] Administrator password must be at least 8 characters long.", file=sys.stderr)
        return False

    init_db()
    normalized_email = email.lower().strip()

    with get_db() as conn:
        cursor = conn.cursor()
        cursor.execute("SELECT id, role FROM users WHERE email = ?", (normalized_email,))
        existing = cursor.fetchone()

        if existing:
            if existing["role"] == "admin":
                print(f"[INFO] Administrator account '{normalized_email}' already exists. No action needed.")
                return True
            else:
                cursor.execute(
                    "UPDATE users SET role = 'admin' WHERE id = ?",
                    (existing["id"],)
                )
                print(f"[SUCCESS] Upgraded existing account '{normalized_email}' to administrator role.")
                return True

        hashed = hash_password(password)
        now_str = datetime.now(timezone.utc).isoformat()
        cursor.execute(
            """
            INSERT INTO users (email, password_hash, full_name, role, is_active, created_at)
            VALUES (?, ?, ?, 'admin', 1, ?)
            """,
            (normalized_email, hashed, full_name, now_str)
        )
        print(f"[SUCCESS] Administrator account '{normalized_email}' successfully created.")
        return True


def seed_from_env_if_configured() -> None:
    """Invoked on application startup if initial admin credentials are provided."""
    env_email = os.getenv("ADMIN_INITIAL_EMAIL")
    env_password = os.getenv("ADMIN_INITIAL_PASSWORD")
    env_name = os.getenv("ADMIN_INITIAL_NAME", "System Administrator")

    if env_email and env_password:
        with get_db() as conn:
            cursor = conn.cursor()
            cursor.execute("SELECT COUNT(*) as cnt FROM users WHERE role = 'admin'")
            admin_count = cursor.fetchone()["cnt"]

        if admin_count == 0:
            seed_administrator(env_email, env_password, env_name)


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="CreditWise Administrator Provisioning Tool")
    parser.add_argument("--email", default=os.getenv("ADMIN_INITIAL_EMAIL"))
    parser.add_argument("--password", default=os.getenv("ADMIN_INITIAL_PASSWORD"))
    parser.add_argument("--name", default=os.getenv("ADMIN_INITIAL_NAME", "System Administrator"))

    args = parser.parse_args()

    email = args.email
    password = args.password
    name = args.name

    if not email:
        email = input("Enter administrator email: ").strip()
    if not password:
        import getpass
        password = getpass.getpass("Enter secure administrator password: ").strip()

    success = seed_administrator(email, password, name)
    sys.exit(0 if success else 1)
