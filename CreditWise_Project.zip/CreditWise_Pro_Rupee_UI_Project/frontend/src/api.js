import axios from 'axios';

const API_BASE_URL = import.meta.env.VITE_API_BASE_URL || 'http://127.0.0.1:8000';

const api = axios.create({
  baseURL: API_BASE_URL,
  headers: {
    'Content-Type': 'application/json',
  },
});

// Attach Bearer token to all outgoing requests
api.interceptors.request.use(
  (config) => {
    const token = localStorage.getItem('creditwise_token');
    if (token) {
      config.headers.Authorization = `Bearer ${token}`;
    }
    return config;
  },
  (error) => Promise.reject(error)
);

// Intercept 401 errors for automatic logout when token expires
api.interceptors.response.use(
  (response) => response,
  (error) => {
    if (error.response && error.response.status === 401) {
      // If unauthorized, clear saved token
      localStorage.removeItem('creditwise_token');
      localStorage.removeItem('creditwise_user');
      if (window.location.pathname !== '/login' && window.location.pathname !== '/register' && window.location.pathname !== '/') {
        window.location.href = '/login?expired=true';
      }
    }
    return Promise.reject(error);
  }
);

export const authAPI = {
  register: (data) => api.post('/auth/register', data),
  login: (data) => api.post('/auth/login', data),
  adminLogin: (data) => api.post('/auth/admin/login', data),
  getMe: () => api.get('/auth/me'),
};

export const predictionAPI = {
  predict: (data) => api.post('/predictions', data),
  getHistory: () => api.get('/predictions/history'),
};

export const adminAPI = {
  getOverview: () => api.get('/admin/overview'),
  getModelComparison: () => api.get('/admin/model-comparison'),
  getConfusionMatrix: (model) => api.get(`/admin/model-comparison/${model}/confusion-matrix`),
  getRocCurves: () => api.get('/admin/model-comparison/roc-curves'),
};

export default api;
