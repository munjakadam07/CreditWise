/**
 * Frontend unit, validation, and integration tests.
 * Runs in Node.js environment to verify frontend logic and API contracts.
 */

import assert from 'assert';
import {
  buildMetricChartData,
  VERIFIED_MODELS_FALLBACK,
} from '../components/metricChartUtils.js';

console.log('====================================================');
console.log(' CreditWise Frontend Logic & Integration Test Suite ');
console.log('====================================================\n');

let passedTests = 0;
let totalTests = 0;

function test(name, fn) {
  totalTests++;
  try {
    fn();
    console.log(`[PASS] ${name}`);
    passedTests++;
  } catch (err) {
    console.error(`[FAIL] ${name}`);
    console.error(`       Error: ${err.message}`);
    process.exitCode = 1;
  }
}

async function asyncTest(name, fn) {
  totalTests++;
  try {
    await fn();
    console.log(`[PASS] ${name}`);
    passedTests++;
  } catch (err) {
    console.error(`[FAIL] ${name}`);
    console.error(`       Error: ${err.message}`);
    process.exitCode = 1;
  }
}

// ==========================================
// 1. Password & Form Validation
// ==========================================

test('Password complexity requires length >= 8 with letters and numbers', () => {
  const validatePassword = (pwd) => {
    if (!pwd || pwd.length < 8) return false;
    const hasLetter = /[A-Za-z]/.test(pwd);
    const hasNumber = /[0-9]/.test(pwd);
    return hasLetter && hasNumber;
  };

  assert.strictEqual(validatePassword('short1'), false, 'Too short should fail');
  assert.strictEqual(validatePassword('onlylettershere'), false, 'No digits should fail');
  assert.strictEqual(validatePassword('1234567890'), false, 'No letters should fail');
  assert.strictEqual(validatePassword('ValidPass123!'), true, 'Valid password should pass');
});

// ==========================================
// 2. Rupee & Lakh Conversion Exact Math
// ==========================================

test('Rupee inputs scale to exact model units (₹ / 100 and Lakh * 1000)', () => {
  const convertInputs = (applicantRupees, coapplicantRupees, savingsRupees, collateralRupees, loanLakh) => {
    return {
      Applicant_Income: applicantRupees / 100.0,
      Coapplicant_Income: coapplicantRupees / 100.0,
      Savings: savingsRupees / 100.0,
      Collateral_Value: collateralRupees / 100.0,
      Loan_Amount: loanLakh * 1000.0,
    };
  };

  const converted = convertInputs(1000000, 300000, 1000000, 3000000, 20.0);

  assert.strictEqual(converted.Applicant_Income, 10000.0);
  assert.strictEqual(converted.Coapplicant_Income, 3000.0);
  assert.strictEqual(converted.Savings, 10000.0);
  assert.strictEqual(converted.Collateral_Value, 30000.0);
  assert.strictEqual(converted.Loan_Amount, 20000.0);
});

// ==========================================
// 3. Out-of-Distribution Boundary Checks
// ==========================================

test('Out-of-distribution values are detected against training limits', () => {
  const checkBounds = (feature, value, bounds) => {
    if (value < bounds.min || value > bounds.max) {
      return `${feature}: ${value} is outside [${bounds.min}, ${bounds.max}]`;
    }
    return null;
  };

  const applicantBounds = { min: 2009.0, max: 19988.0 };
  const creditBounds = { min: 550.0, max: 799.0 };

  // Valid 10,000 units
  assert.strictEqual(checkBounds('Applicant_Income', 10000.0, applicantBounds), null);

  // Invalid 50,000 units (₹50 Lakh)
  assert.ok(checkBounds('Applicant_Income', 50000.0, applicantBounds) !== null);

  // Invalid credit score 850
  assert.ok(checkBounds('Credit_Score', 850.0, creditBounds) !== null);
});

// ==========================================
// 4. Confusion Matrix Calculation Integrity
// ==========================================

test('Confusion matrix totals match holdout sample count (190)', () => {
  const matrix = {
    true_negatives: 124,
    false_positives: 6,
    false_negatives: 2,
    true_positives: 58,
    sample_count: 190,
  };

  const sum = matrix.true_negatives + matrix.false_positives + matrix.false_negatives + matrix.true_positives;
  assert.strictEqual(sum, matrix.sample_count);
  assert.strictEqual(sum, 190);
});

// ==========================================
// 5. Role-Based Access Control & Navigation Logic
// ==========================================

test('AuthContext role logic accurately identifies admin vs customer accounts', () => {
  const evaluateRole = (user) => ({
    isAuthenticated: !!user,
    isAdmin: user?.role === 'admin',
  });

  const unauthenticated = evaluateRole(null);
  assert.strictEqual(unauthenticated.isAuthenticated, false);
  assert.strictEqual(unauthenticated.isAdmin, false);

  const customerUser = evaluateRole({ id: 4, email: 'user@example.com', role: 'customer' });
  assert.strictEqual(customerUser.isAuthenticated, true);
  assert.strictEqual(customerUser.isAdmin, false);

  const adminUser = evaluateRole({ id: 1, email: 'admin@creditwise.local', role: 'admin' });
  assert.strictEqual(adminUser.isAuthenticated, true);
  assert.strictEqual(adminUser.isAdmin, true);
});

test('ProtectedRoute guard blocks unauthenticated and customer access to admin routes', () => {
  const checkRouteAccess = ({ isAuthenticated, isAdmin, requireAdmin }) => {
    if (!isAuthenticated) return { allow: false, redirect: '/login' };
    if (requireAdmin && !isAdmin) return { allow: false, redirect: '/dashboard' };
    return { allow: true, redirect: null };
  };

  // 1. Unauthenticated visiting /admin
  const unauthAccess = checkRouteAccess({ isAuthenticated: false, isAdmin: false, requireAdmin: true });
  assert.strictEqual(unauthAccess.allow, false);
  assert.strictEqual(unauthAccess.redirect, '/login');

  // 2. Customer visiting /admin
  const customerAccess = checkRouteAccess({ isAuthenticated: true, isAdmin: false, requireAdmin: true });
  assert.strictEqual(customerAccess.allow, false);
  assert.strictEqual(customerAccess.redirect, '/dashboard');

  // 3. Admin visiting /admin
  const adminAccess = checkRouteAccess({ isAuthenticated: true, isAdmin: true, requireAdmin: true });
  assert.strictEqual(adminAccess.allow, true);
  assert.strictEqual(adminAccess.redirect, null);

  // 4. Customer visiting normal route
  const custNormal = checkRouteAccess({ isAuthenticated: true, isAdmin: false, requireAdmin: false });
  assert.strictEqual(custNormal.allow, true);
});

// ==========================================
// 6. Dual Login Navigation & Redirection
// ==========================================

test('Customer login resolves target route strictly to /dashboard', () => {
  const resolveLoginDestination = (role, defaultDestination = '/dashboard') => {
    if (role === 'admin') return '/admin';
    return defaultDestination;
  };

  const customerTarget = resolveLoginDestination('customer');
  assert.strictEqual(customerTarget, '/dashboard', 'Customer login must open /dashboard');

  const adminTarget = resolveLoginDestination('admin');
  assert.strictEqual(adminTarget, '/admin', 'Admin login must open /admin');
});

test('Admin login rejects customer credentials and validates admin role requirement', () => {
  const validateAdminLoginResponse = (userProfile) => {
    if (userProfile.role !== 'admin') {
      throw new Error('Access denied: Customer credentials cannot be used for administrative login.');
    }
    return true;
  };

  // 1. Admin user profile succeeds
  assert.doesNotThrow(() => {
    validateAdminLoginResponse({ id: 1, email: 'admin@creditwise.local', role: 'admin' });
  });

  // 2. Customer user profile throws error
  assert.throws(() => {
    validateAdminLoginResponse({ id: 4, email: 'customer@example.com', role: 'customer' });
  }, /Access denied: Customer credentials cannot be used for administrative login/);
});

// ==========================================
// 7. Model Comparison Metric Chart Data Mapping & Verified Holdout Integrity
// ==========================================

test('buildMetricChartData correctly maps all 5 holdout metrics matching exact verified values', () => {
  const verifiedValues = {
    accuracy: { gb: 95.79, rf: 93.16, lr: 88.42 },
    precision: { gb: 90.62, rf: 88.52, lr: 85.19 },
    recall: { gb: 96.67, rf: 90.00, lr: 76.67 },
    f1_score: { gb: 93.55, rf: 89.26, lr: 80.70 },
    roc_auc: { gb: 98.77, rf: 98.52, lr: 92.06 },
  };

  Object.entries(verifiedValues).forEach(([metric, expected]) => {
    const chartData = buildMetricChartData(VERIFIED_MODELS_FALLBACK, metric);
    assert.strictEqual(chartData.length, 3, `${metric} must compare exactly 3 models`);

    const gb = chartData.find((d) => d.modelKey === 'gradient_boosting');
    const rf = chartData.find((d) => d.modelKey === 'random_forest');
    const lr = chartData.find((d) => d.modelKey === 'logistic_regression');

    assert.strictEqual(gb.score, expected.gb, `${metric} GB score mismatch`);
    assert.strictEqual(rf.score, expected.rf, `${metric} RF score mismatch`);
    assert.strictEqual(lr.score, expected.lr, `${metric} LR score mismatch`);

    assert.strictEqual(gb.displayValue, `${expected.gb.toFixed(2)}%`);
    assert.strictEqual(rf.displayValue, `${expected.rf.toFixed(2)}%`);
    assert.strictEqual(lr.displayValue, `${expected.lr.toFixed(2)}%`);
  });
});

test('buildMetricChartData maps cross-validation metrics with accurate standard-deviation error bounds', () => {
  // CV ROC-AUC
  const cvRocData = buildMetricChartData(VERIFIED_MODELS_FALLBACK, 'cv_mean_roc_auc', 'cv_std_roc_auc');
  assert.strictEqual(cvRocData.length, 3);
  const gbRoc = cvRocData.find((d) => d.modelKey === 'gradient_boosting');
  const rfRoc = cvRocData.find((d) => d.modelKey === 'random_forest');
  const lrRoc = cvRocData.find((d) => d.modelKey === 'logistic_regression');

  assert.strictEqual(gbRoc.score, 98.77);
  assert.strictEqual(gbRoc.error, 0.54);
  assert.strictEqual(rfRoc.score, 98.00);
  assert.strictEqual(rfRoc.error, 0.54);
  assert.strictEqual(lrRoc.score, 92.40);
  assert.strictEqual(lrRoc.error, 0.79);

  // CV Accuracy
  const cvAccData = buildMetricChartData(VERIFIED_MODELS_FALLBACK, 'cv_mean_accuracy', 'cv_std_accuracy');
  assert.strictEqual(cvAccData.length, 3);
  const gbAcc = cvAccData.find((d) => d.modelKey === 'gradient_boosting');
  const rfAcc = cvAccData.find((d) => d.modelKey === 'random_forest');
  const lrAcc = cvAccData.find((d) => d.modelKey === 'logistic_regression');

  assert.strictEqual(gbAcc.score, 95.79);
  assert.strictEqual(gbAcc.error, 0.88);
  assert.strictEqual(rfAcc.score, 94.11);
  assert.strictEqual(rfAcc.error, 0.52);
  assert.strictEqual(lrAcc.score, 85.16);
  assert.strictEqual(lrAcc.error, 1.71);
});

test('buildMetricChartData safely falls back to verified evaluation artifacts when input is null or empty', () => {
  const fallbackData = buildMetricChartData(null, 'accuracy');
  assert.strictEqual(fallbackData.length, 3);
  assert.strictEqual(fallbackData[0].model, 'Gradient Boosting');
  assert.strictEqual(fallbackData[0].score, 95.79);
  assert.strictEqual(fallbackData[1].model, 'Random Forest');
  assert.strictEqual(fallbackData[1].score, 93.16);
  assert.strictEqual(fallbackData[2].model, 'Logistic Regression');
  assert.strictEqual(fallbackData[2].score, 88.42);
});

console.log(`\nTests completed. Passed: ${passedTests}/${totalTests}`);
if (passedTests === totalTests) {
  console.log('All frontend logic checks passed successfully!\n');
}


