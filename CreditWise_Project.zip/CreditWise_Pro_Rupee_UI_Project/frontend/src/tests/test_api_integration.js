/**
 * Live End-to-End API Integration Test against running FastAPI backend.
 */

import assert from 'assert';

const API_BASE = 'http://127.0.0.1:8000';

async function request(path, options = {}) {
  const url = `${API_BASE}${path}`;
  const headers = { 'Content-Type': 'application/json', ...(options.headers || {}) };
  const res = await fetch(url, { ...options, headers });
  const data = await res.json().catch(() => null);
  return { status: res.status, ok: res.ok, data };
}

async function runLiveIntegrationTests() {
  console.log('====================================================');
  console.log(' Live FastAPI Backend & API Integration Test Suite  ');
  console.log('====================================================\n');

  // 1. Health check
  console.log('-> Testing GET /health...');
  const health = await request('/health');
  assert.strictEqual(health.status, 200);
  assert.strictEqual(health.data.status, 'healthy');
  assert.strictEqual(health.data.model_loaded, true);
  console.log('   [PASS] Health check verified. Model loaded in memory.');

  // 2. Register customer
  const testEmail = `cust_${Date.now()}@example.com`;
  console.log(`-> Testing POST /auth/register with ${testEmail}...`);
  const reg = await request('/auth/register', {
    method: 'POST',
    body: JSON.stringify({
      email: testEmail,
      password: 'StrongPassword123!',
      full_name: 'Integration Test Customer',
    }),
  });
  assert.strictEqual(reg.status, 201);
  assert.ok(reg.data.access_token);
  assert.strictEqual(reg.data.user.role, 'customer');
  const customerToken = reg.data.access_token;
  console.log('   [PASS] Customer registered and received signed JWT access token.');

  // 3. Current user /auth/me
  console.log('-> Testing GET /auth/me...');
  const me = await request('/auth/me', {
    headers: { Authorization: `Bearer ${customerToken}` },
  });
  assert.strictEqual(me.status, 200);
  assert.strictEqual(me.data.email, testEmail);
  console.log('   [PASS] Current user profile matches authenticated session.');

  // 4. Create prediction with Rupee inputs
  console.log('-> Testing POST /predictions with Rupee inputs...');
  const pred = await request('/predictions', {
    method: 'POST',
    headers: { Authorization: `Bearer ${customerToken}` },
    body: JSON.stringify({
      applicant_income_rupees: 1000000,
      coapplicant_income_rupees: 300000,
      savings_rupees: 1000000,
      collateral_value_rupees: 3000000,
      loan_amount_lakh: 20.0,
      age: 30,
      dependents: 0,
      credit_score: 700,
      existing_loans: 1,
      dti_ratio: 0.30,
      loan_term: 36,
      employment_status: 'Salaried',
      marital_status: 'Married',
      loan_purpose: 'Personal',
      property_area: 'Urban',
      education_level: 'Graduate',
      gender: 'Male',
      employer_category: 'Private',
    }),
  });
  assert.strictEqual(pred.status, 200);
  assert.ok(pred.data.id);
  assert.ok(pred.data.approval_probability >= 0 && pred.data.approval_probability <= 1);
  assert.strictEqual(pred.data.decision_threshold, 0.50);
  assert.ok(['Approved', 'Rejected'].includes(pred.data.decision_label));
  const createdPredId = pred.data.id;
  console.log(`   [PASS] Prediction created (ID: #${createdPredId}, Decision: ${pred.data.decision_label}, Prob: ${(pred.data.approval_probability * 100).toFixed(1)}%).`);

  // 5. Customer History Isolation
  console.log('-> Testing GET /predictions/history...');
  const hist = await request('/predictions/history', {
    headers: { Authorization: `Bearer ${customerToken}` },
  });
  assert.strictEqual(hist.status, 200);
  assert.ok(Array.isArray(hist.data));
  assert.ok(hist.data.some((p) => p.id === createdPredId));
  console.log(`   [PASS] Customer history accurately returned isolated prediction record.`);

  // 6. Security Boundary: Customer accessing Admin endpoint is blocked
  console.log('-> Testing Customer attempting to access GET /admin/overview (must be 403 Forbidden)...');
  const forbidden = await request('/admin/overview', {
    headers: { Authorization: `Bearer ${customerToken}` },
  });
  assert.strictEqual(forbidden.status, 403);
  console.log('   [PASS] Security boundary enforced: Customer blocked from admin endpoint with 403.');

  // 7. Admin Login & Verified Metrics
  console.log('-> Testing Admin login via POST /auth/admin/login (username: admin)...');
  const adminLoginByUsername = await request('/auth/admin/login', {
    method: 'POST',
    body: JSON.stringify({
      username: 'admin',
      password: 'SecureAdminPassword2026!',
    }),
  });
  assert.strictEqual(adminLoginByUsername.status, 200);
  assert.strictEqual(adminLoginByUsername.data.user.role, 'admin');
  console.log('   [PASS] Admin authenticated via username "admin".');

  console.log('-> Testing Admin login via POST /auth/admin/login (email: admin@test.local)...');
  const adminLogin = await request('/auth/admin/login', {
    method: 'POST',
    body: JSON.stringify({
      username: 'admin@test.local',
      password: 'SecureAdminPassword2026!',
    }),
  });
  assert.strictEqual(adminLogin.status, 200);
  assert.strictEqual(adminLogin.data.user.role, 'admin');
  const adminToken = adminLogin.data.access_token;
  console.log('   [PASS] Admin authenticated via email.');

  console.log('-> Testing customer credentials rejected on POST /auth/admin/login (must be 403)...');
  const customerAdminAttempt = await request('/auth/admin/login', {
    method: 'POST',
    body: JSON.stringify({
      username: testEmail,
      password: 'StrongPassword123!',
    }),
  });
  assert.strictEqual(customerAdminAttempt.status, 403);
  console.log('   [PASS] Customer credentials rejected on admin login with 403.');

  console.log('-> Testing invalid admin credentials rejected on POST /auth/admin/login (must be 401)...');
  const invalidAdminAttempt = await request('/auth/admin/login', {
    method: 'POST',
    body: JSON.stringify({
      username: 'admin',
      password: 'WrongPassword999!',
    }),
  });
  assert.strictEqual(invalidAdminAttempt.status, 401);
  console.log('   [PASS] Invalid admin credentials rejected with 401.');

  const adminOverview = await request('/admin/overview', {
    headers: { Authorization: `Bearer ${adminToken}` },
  });
  assert.strictEqual(adminOverview.status, 200);
  assert.ok(adminOverview.data.total_users >= 1);

  const modelComp = await request('/admin/model-comparison', {
    headers: { Authorization: `Bearer ${adminToken}` },
  });
  assert.strictEqual(modelComp.status, 200);
  assert.strictEqual(modelComp.data.models.length, 3);
  console.log('   [PASS] Admin retrieved overview and verified 3-model benchmark metrics.');

  const roc = await request('/admin/model-comparison/roc-curves', {
    headers: { Authorization: `Bearer ${adminToken}` },
  });
  assert.strictEqual(roc.status, 200);
  assert.ok(roc.data.gradient_boosting);
  console.log('   [PASS] Admin retrieved comparative ROC curve coordinates.');

  console.log('\n====================================================');
  console.log(' ALL LIVE BACKEND INTEGRATION TESTS PASSED 100%!   ');
  console.log('====================================================\n');
}

runLiveIntegrationTests().catch((err) => {
  console.error('\n[INTEGRATION TEST FAILURE]', err);
  process.exit(1);
});
