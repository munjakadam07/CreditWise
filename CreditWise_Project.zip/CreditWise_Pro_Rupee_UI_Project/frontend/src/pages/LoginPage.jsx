import React, { useState, useEffect } from 'react';
import { Link, useNavigate, useLocation } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import { LogIn, ShieldAlert, User, AlertCircle, Info, Lock } from 'lucide-react';

export const LoginPage = () => {
  const { login, adminLogin } = useAuth();
  const navigate = useNavigate();
  const location = useLocation();

  // Active tab: 'customer' | 'admin'
  const [activeTab, setActiveTab] = useState(() => {
    const params = new URLSearchParams(location.search);
    return params.get('tab') === 'admin' ? 'admin' : 'customer';
  });

  // Customer Form State
  const [customerData, setCustomerData] = useState({
    email: '',
    password: '',
  });

  // Admin Form State
  const [adminData, setAdminData] = useState({
    username: '',
    password: '',
  });

  const [error, setError] = useState('');
  const [sessionExpiredNotice, setSessionExpiredNotice] = useState(false);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    const params = new URLSearchParams(location.search);
    if (params.get('expired') === 'true') {
      setSessionExpiredNotice(true);
    }
    if (params.get('tab') === 'admin') {
      setActiveTab('admin');
    }
  }, [location]);

  const handleTabSwitch = (tab) => {
    setActiveTab(tab);
    setError('');
  };

  const handleCustomerSubmit = async (e) => {
    e.preventDefault();
    setError('');
    setLoading(true);

    try {
      await login(customerData.email, customerData.password);
      // Requirement: Successful customer login must open /dashboard
      navigate('/dashboard', { replace: true });
    } catch (err) {
      const detail = err.response?.data?.detail;
      if (typeof detail === 'string') {
        setError(detail);
      } else {
        setError('Login failed. Please verify your email and password.');
      }
    } finally {
      setLoading(false);
    }
  };

  const handleAdminSubmit = async (e) => {
    e.preventDefault();
    setError('');
    setLoading(true);

    try {
      await adminLogin(adminData.username, adminData.password);
      // Requirement: Successful admin login must open /admin
      navigate('/admin', { replace: true });
    } catch (err) {
      const detail = err.response?.data?.detail;
      if (typeof detail === 'string') {
        setError(detail);
      } else {
        setError('Administrator authentication failed. Please check your credentials.');
      }
    } finally {
      setLoading(false);
    }
  };

  return (
    <div style={{ maxWidth: '480px', margin: '2.5rem auto' }}>
      <div className="card" style={{ padding: '2rem' }}>
        {/* Tab Selection Header */}
        <div
          style={{
            display: 'flex',
            background: 'var(--bg-main)',
            padding: '0.35rem',
            borderRadius: 'var(--radius-sm)',
            marginBottom: '1.75rem',
            border: '1px solid var(--border)',
          }}
        >
          <button
            type="button"
            onClick={() => handleTabSwitch('customer')}
            style={{
              flex: 1,
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
              gap: '0.45rem',
              padding: '0.65rem',
              fontSize: '0.9rem',
              fontWeight: 700,
              borderRadius: '6px',
              border: 'none',
              cursor: 'pointer',
              background: activeTab === 'customer' ? '#ffffff' : 'transparent',
              color: activeTab === 'customer' ? 'var(--primary)' : 'var(--text-secondary)',
              boxShadow: activeTab === 'customer' ? 'var(--shadow-sm)' : 'none',
              transition: 'all 0.15s ease',
            }}
          >
            <User size={16} /> Customer Login
          </button>

          <button
            type="button"
            onClick={() => handleTabSwitch('admin')}
            style={{
              flex: 1,
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
              gap: '0.45rem',
              padding: '0.65rem',
              fontSize: '0.9rem',
              fontWeight: 700,
              borderRadius: '6px',
              border: 'none',
              cursor: 'pointer',
              background: activeTab === 'admin' ? '#ffffff' : 'transparent',
              color: activeTab === 'admin' ? '#dc2626' : 'var(--text-secondary)',
              boxShadow: activeTab === 'admin' ? 'var(--shadow-sm)' : 'none',
              transition: 'all 0.15s ease',
            }}
          >
            <ShieldAlert size={16} /> Admin Login
          </button>
        </div>

        {/* Notices and Alerts */}
        {sessionExpiredNotice && (
          <div className="alert alert-warning" style={{ marginBottom: '1.25rem' }}>
            <Info size={18} style={{ flexShrink: 0 }} />
            <span>Your session has expired. Please sign in again.</span>
          </div>
        )}

        {error && (
          <div className="alert alert-danger" style={{ marginBottom: '1.25rem' }}>
            <AlertCircle size={18} style={{ flexShrink: 0 }} />
            <span>{error}</span>
          </div>
        )}

        {/* TAB 1: CUSTOMER LOGIN */}
        {activeTab === 'customer' && (
          <div>
            <div style={{ textAlign: 'center', marginBottom: '1.5rem' }}>
              <div
                style={{
                  display: 'inline-flex',
                  padding: '0.75rem',
                  background: 'var(--primary-light)',
                  borderRadius: '50%',
                  color: 'var(--primary)',
                  marginBottom: '0.5rem',
                }}
              >
                <LogIn size={24} />
              </div>
              <h1 style={{ fontSize: '1.45rem', fontWeight: 800 }}>Customer Portal</h1>
              <p style={{ fontSize: '0.85rem', color: 'var(--text-secondary)', marginTop: '0.2rem' }}>
                Sign in to calculate loan approvals and review your history.
              </p>
            </div>

            <form onSubmit={handleCustomerSubmit}>
              <div className="form-group">
                <label className="form-label" htmlFor="customer-email">
                  Email Address
                </label>
                <input
                  id="customer-email"
                  name="email"
                  type="email"
                  className="form-input"
                  placeholder="applicant@example.com"
                  value={customerData.email}
                  onChange={(e) => setCustomerData((prev) => ({ ...prev, email: e.target.value }))}
                  required
                  disabled={loading}
                />
              </div>

              <div className="form-group">
                <label className="form-label" htmlFor="customer-password">
                  Password
                </label>
                <input
                  id="customer-password"
                  name="password"
                  type="password"
                  className="form-input"
                  placeholder="Enter your password"
                  value={customerData.password}
                  onChange={(e) => setCustomerData((prev) => ({ ...prev, password: e.target.value }))}
                  required
                  disabled={loading}
                />
              </div>

              <button
                type="submit"
                className="btn btn-primary"
                style={{ width: '100%', marginTop: '0.5rem', padding: '0.75rem' }}
                disabled={loading}
              >
                {loading ? 'Authenticating...' : 'Sign In as Customer'}
              </button>
            </form>

            <div
              style={{
                textAlign: 'center',
                marginTop: '1.5rem',
                fontSize: '0.88rem',
                color: 'var(--text-secondary)',
                borderTop: '1px solid var(--border)',
                paddingTop: '1.25rem',
              }}
            >
              Don't have an account?{' '}
              <Link to="/register" style={{ fontWeight: 600 }}>
                Register as Customer
              </Link>
            </div>
          </div>
        )}

        {/* TAB 2: ADMIN LOGIN */}
        {activeTab === 'admin' && (
          <div>
            <div style={{ textAlign: 'center', marginBottom: '1.25rem' }}>
              <div
                style={{
                  display: 'inline-flex',
                  padding: '0.75rem',
                  background: '#fee2e2',
                  borderRadius: '50%',
                  color: '#dc2626',
                  marginBottom: '0.5rem',
                }}
              >
                <Lock size={24} />
              </div>
              <h1 style={{ fontSize: '1.45rem', fontWeight: 800 }}>Administrator Portal</h1>
              <p style={{ fontSize: '0.85rem', color: 'var(--text-secondary)', marginTop: '0.2rem' }}>
                Restricted portal for ML model governance and audit telemetry.
              </p>
            </div>

            <div
              style={{
                background: '#fef2f2',
                border: '1px solid #fecaca',
                borderRadius: 'var(--radius-sm)',
                padding: '0.65rem 0.85rem',
                fontSize: '0.8rem',
                color: '#991b1b',
                display: 'flex',
                alignItems: 'center',
                gap: '0.5rem',
                marginBottom: '1.25rem',
              }}
            >
              <ShieldAlert size={16} style={{ flexShrink: 0 }} />
              <span>Restricted Access: Authorized administrator credentials only.</span>
            </div>

            <form onSubmit={handleAdminSubmit}>
              <div className="form-group">
                <label className="form-label" htmlFor="admin-username">
                  Administrator Username or Email
                </label>
                <input
                  id="admin-username"
                  name="username"
                  type="text"
                  className="form-input"
                  placeholder="admin or admin@creditwise.local"
                  value={adminData.username}
                  onChange={(e) => setAdminData((prev) => ({ ...prev, username: e.target.value }))}
                  required
                  disabled={loading}
                />
              </div>

              <div className="form-group">
                <label className="form-label" htmlFor="admin-password">
                  Administrator Password
                </label>
                <input
                  id="admin-password"
                  name="password"
                  type="password"
                  className="form-input"
                  placeholder="Enter administrator password"
                  value={adminData.password}
                  onChange={(e) => setAdminData((prev) => ({ ...prev, password: e.target.value }))}
                  required
                  disabled={loading}
                />
              </div>

              <button
                type="submit"
                className="btn btn-primary"
                style={{
                  width: '100%',
                  marginTop: '0.5rem',
                  padding: '0.75rem',
                  background: '#dc2626',
                  borderColor: '#dc2626',
                }}
                disabled={loading}
              >
                {loading ? 'Verifying Credentials...' : 'Sign In to Admin Portal'}
              </button>
            </form>

            <div
              style={{
                textAlign: 'center',
                marginTop: '1.5rem',
                fontSize: '0.78rem',
                color: 'var(--text-muted)',
                borderTop: '1px solid var(--border)',
                paddingTop: '1rem',
              }}
            >
              Security Note: Administrative accounts are securely provisioned via backend CLI.
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default LoginPage;

