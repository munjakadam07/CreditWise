import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { predictionAPI } from '../api';
import {
  CreditCard,
  CheckCircle2,
  XCircle,
  AlertTriangle,
  HelpCircle,
  TrendingUp,
  History,
  Info,
} from 'lucide-react';

export const PredictPage = () => {
  const [formData, setFormData] = useState({
    applicant_income_rupees: 1000000,
    coapplicant_income_rupees: 300000,
    savings_rupees: 1000000,
    collateral_value_rupees: 3000000,
    loan_amount_lakh: 20.0,
    age: 30,
    dependents: 0,
    credit_score: 700,
    existing_loans: 1,
    dti_ratio: 0.30,
    loan_term: 36,
    employment_status: 'Salaried',
    marital_status: 'Married',
    loan_purpose: 'Personal',
    property_area: 'Urban',
    education_level: 'Graduate',
    gender: 'Male',
    employer_category: 'Private',
  });

  const [loading, setLoading] = useState(false);
  const [result, setResult] = useState(null);
  const [error, setError] = useState(null);
  const [violations, setViolations] = useState([]);

  const handleChange = (e) => {
    const { name, value, type } = e.target;
    setFormData((prev) => ({
      ...prev,
      [name]: type === 'number' ? (value === '' ? '' : parseFloat(value)) : value,
    }));
    setError(null);
    setViolations([]);
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);
    setError(null);
    setViolations([]);
    setResult(null);

    try {
      const res = await predictionAPI.predict(formData);
      setResult(res.data);
    } catch (err) {
      const resData = err.response?.data;
      if (err.response?.status === 422) {
        if (resData?.detail?.violations) {
          setError(resData.detail.message || 'Input outside observed training distribution.');
          setViolations(resData.detail.violations);
        } else if (Array.isArray(resData?.detail)) {
          setError(resData.detail[0]?.msg || 'Validation failed. Check your inputs.');
        } else {
          setError(typeof resData?.detail === 'string' ? resData.detail : 'Validation error.');
        }
      } else {
        setError('Prediction service error. Please try again.');
      }
    } finally {
      setLoading(false);
    }
  };

  return (
    <div>
      <div style={{ marginBottom: '1.75rem' }}>
        <h1 style={{ fontSize: '1.85rem', fontWeight: 800 }}>Loan Eligibility Prediction</h1>
        <p style={{ color: 'var(--text-secondary)', fontSize: '0.92rem' }}>
          Enter financial metrics in Indian Rupees (₹) and Lakhs. The model validates against historical distributions.
        </p>
      </div>

      {violations.length > 0 && (
        <div className="alert alert-danger" style={{ display: 'block' }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: '0.5rem', fontWeight: 700, marginBottom: '0.5rem' }}>
            <AlertTriangle size={18} /> Out-of-Distribution Warning
          </div>
          <p style={{ fontSize: '0.88rem', marginBottom: '0.5rem' }}>{error}</p>
          <ul style={{ paddingLeft: '1.25rem', fontSize: '0.85rem' }}>
            {violations.map((v, i) => (
              <li key={i}>{v}</li>
            ))}
          </ul>
        </div>
      )}

      {error && violations.length === 0 && (
        <div className="alert alert-danger">
          <XCircle size={18} style={{ flexShrink: 0 }} />
          <span>{error}</span>
        </div>
      )}

      {result && (
        <div
          className="card"
          style={{
            marginBottom: '2rem',
            background: result.prediction === 1 ? '#f0fdf4' : '#fef2f2',
            border: `1px solid ${result.prediction === 1 ? '#86efac' : '#fca5a5'}`,
          }}
        >
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', flexWrap: 'wrap', gap: '1rem' }}>
            <div style={{ display: 'flex', alignItems: 'center', gap: '0.75rem' }}>
              {result.prediction === 1 ? (
                <CheckCircle2 size={36} color="#16a34a" />
              ) : (
                <XCircle size={36} color="#dc2626" />
              )}
              <div>
                <h2 style={{ fontSize: '1.4rem', fontWeight: 800, color: result.prediction === 1 ? '#15803d' : '#b91c1c' }}>
                  {result.decision_label === 'Approved' ? 'Likely Approved' : 'Likely Rejected'}
                </h2>
                <div style={{ fontSize: '0.85rem', color: 'var(--text-secondary)' }}>
                  Evaluated using {result.model_version} • Decision Threshold: {(result.decision_threshold * 100).toFixed(0)}%
                </div>
              </div>
            </div>

            <Link to="/history" className="btn btn-outline btn-sm">
              <History size={16} /> View in History
            </Link>
          </div>

          <div className="grid-3" style={{ marginTop: '1.25rem' }}>
            <div style={{ background: '#ffffff', padding: '1rem', borderRadius: '8px', border: '1px solid var(--border)' }}>
              <div style={{ fontSize: '0.8rem', color: 'var(--text-secondary)', fontWeight: 600 }}>Approval Probability</div>
              <div style={{ fontSize: '1.75rem', fontWeight: 800, color: '#16a34a' }}>
                {(result.approval_probability * 100).toFixed(1)}%
              </div>
            </div>

            <div style={{ background: '#ffffff', padding: '1rem', borderRadius: '8px', border: '1px solid var(--border)' }}>
              <div style={{ fontSize: '0.8rem', color: 'var(--text-secondary)', fontWeight: 600 }}>Rejection Probability</div>
              <div style={{ fontSize: '1.75rem', fontWeight: 800, color: '#dc2626' }}>
                {(result.rejection_probability * 100).toFixed(1)}%
              </div>
            </div>

            <div style={{ background: '#ffffff', padding: '1rem', borderRadius: '8px', border: '1px solid var(--border)' }}>
              <div style={{ fontSize: '0.8rem', color: 'var(--text-secondary)', fontWeight: 600 }}>Requested Loan</div>
              <div style={{ fontSize: '1.75rem', fontWeight: 800, color: 'var(--text-primary)' }}>
                ₹{formData.loan_amount_lakh} Lakh
              </div>
            </div>
          </div>

          {result.top_factors && result.top_factors.length > 0 && (
            <div style={{ marginTop: '1.25rem', paddingTop: '1rem', borderTop: '1px dashed var(--border)' }}>
              <div style={{ fontSize: '0.85rem', fontWeight: 700, color: 'var(--text-primary)', marginBottom: '0.5rem', display: 'flex', alignItems: 'center', gap: '0.4rem' }}>
                <TrendingUp size={16} /> Top Contributing Decision Factors
              </div>
              <div style={{ display: 'flex', flexWrap: 'wrap', gap: '0.5rem' }}>
                {result.top_factors.slice(0, 5).map((f, i) => (
                  <span key={i} className="badge-neutral" style={{ background: '#ffffff', border: '1px solid var(--border)' }}>
                    <strong>{f.feature}</strong>: {(f.importance * 100).toFixed(1)}% weight
                  </span>
                ))}
              </div>
            </div>
          )}

          <div style={{ marginTop: '1rem', fontSize: '0.78rem', color: 'var(--text-muted)' }}>
            ⚠️ <em>Disclaimer:</em> This prediction is generated by a statistical model. Final loan approval depends on full lender verification and documentation.
          </div>
        </div>
      )}

      <form onSubmit={handleSubmit} className="card">
        <h2 style={{ fontSize: '1.15rem', fontWeight: 700, marginBottom: '1.25rem', borderBottom: '1px solid var(--border)', paddingBottom: '0.5rem' }}>
          Applicant Financial Profile
        </h2>

        <div className="grid-3">
          {/* Column 1 */}
          <div>
            <div className="form-group">
              <label className="form-label" htmlFor="applicant_income_rupees">
                Applicant Annual Income <span className="unit-badge">₹ (Rupees)</span>
              </label>
              <input
                id="applicant_income_rupees"
                name="applicant_income_rupees"
                type="number"
                step="10000"
                min="200900"
                max="1998800"
                className="form-input"
                value={formData.applicant_income_rupees}
                onChange={handleChange}
                required
              />
            </div>

            <div className="form-group">
              <label className="form-label" htmlFor="age">Age (Years)</label>
              <input
                id="age"
                name="age"
                type="number"
                min="21"
                max="59"
                className="form-input"
                value={formData.age}
                onChange={handleChange}
                required
              />
            </div>

            <div className="form-group">
              <label className="form-label" htmlFor="dependents">Number of Dependents</label>
              <input
                id="dependents"
                name="dependents"
                type="number"
                min="0"
                max="3"
                className="form-input"
                value={formData.dependents}
                onChange={handleChange}
                required
              />
            </div>

            <div className="form-group">
              <label className="form-label" htmlFor="gender">Gender</label>
              <select
                id="gender"
                name="gender"
                className="form-select"
                value={formData.gender}
                onChange={handleChange}
              >
                <option value="Male">Male</option>
                <option value="Female">Female</option>
              </select>
            </div>

            <div className="form-group">
              <label className="form-label" htmlFor="marital_status">Marital Status</label>
              <select
                id="marital_status"
                name="marital_status"
                className="form-select"
                value={formData.marital_status}
                onChange={handleChange}
              >
                <option value="Married">Married</option>
                <option value="Single">Single</option>
              </select>
            </div>

            <div className="form-group">
              <label className="form-label" htmlFor="employment_status">Employment Status</label>
              <select
                id="employment_status"
                name="employment_status"
                className="form-select"
                value={formData.employment_status}
                onChange={handleChange}
              >
                <option value="Salaried">Salaried</option>
                <option value="Self-employed">Self-employed</option>
                <option value="Contract">Contract</option>
                <option value="Unemployed">Unemployed</option>
              </select>
            </div>
          </div>

          {/* Column 2 */}
          <div>
            <div className="form-group">
              <label className="form-label" htmlFor="coapplicant_income_rupees">
                Coapplicant Income <span className="unit-badge">₹ (Rupees)</span>
              </label>
              <input
                id="coapplicant_income_rupees"
                name="coapplicant_income_rupees"
                type="number"
                step="10000"
                min="100"
                max="999600"
                className="form-input"
                value={formData.coapplicant_income_rupees}
                onChange={handleChange}
                required
              />
            </div>

            <div className="form-group">
              <label className="form-label" htmlFor="credit_score">Credit Score (CIBIL)</label>
              <input
                id="credit_score"
                name="credit_score"
                type="number"
                min="550"
                max="799"
                className="form-input"
                value={formData.credit_score}
                onChange={handleChange}
                required
              />
            </div>

            <div className="form-group">
              <label className="form-label" htmlFor="existing_loans">Active Existing Loans</label>
              <input
                id="existing_loans"
                name="existing_loans"
                type="number"
                min="0"
                max="4"
                className="form-input"
                value={formData.existing_loans}
                onChange={handleChange}
                required
              />
            </div>

            <div className="form-group">
              <label className="form-label" htmlFor="dti_ratio">Debt-to-Income (DTI) Ratio</label>
              <input
                id="dti_ratio"
                name="dti_ratio"
                type="number"
                step="0.01"
                min="0.10"
                max="0.60"
                className="form-input"
                value={formData.dti_ratio}
                onChange={handleChange}
                required
              />
            </div>

            <div className="form-group">
              <label className="form-label" htmlFor="savings_rupees">
                Total Savings <span className="unit-badge">₹ (Rupees)</span>
              </label>
              <input
                id="savings_rupees"
                name="savings_rupees"
                type="number"
                step="10000"
                min="7300"
                max="1999600"
                className="form-input"
                value={formData.savings_rupees}
                onChange={handleChange}
                required
              />
            </div>

            <div className="form-group">
              <label className="form-label" htmlFor="property_area">Property Area</label>
              <select
                id="property_area"
                name="property_area"
                className="form-select"
                value={formData.property_area}
                onChange={handleChange}
              >
                <option value="Urban">Urban</option>
                <option value="Semiurban">Semiurban</option>
                <option value="Rural">Rural</option>
              </select>
            </div>
          </div>

          {/* Column 3 */}
          <div>
            <div className="form-group">
              <label className="form-label" htmlFor="collateral_value_rupees">
                Collateral Asset Value <span className="unit-badge">₹ (Rupees)</span>
              </label>
              <input
                id="collateral_value_rupees"
                name="collateral_value_rupees"
                type="number"
                step="25000"
                min="3600"
                max="4995400"
                className="form-input"
                value={formData.collateral_value_rupees}
                onChange={handleChange}
                required
              />
            </div>

            <div className="form-group">
              <label className="form-label" htmlFor="loan_amount_lakh">
                Requested Loan Amount <span className="unit-badge">₹ Lakh</span>
              </label>
              <input
                id="loan_amount_lakh"
                name="loan_amount_lakh"
                type="number"
                step="0.5"
                min="1.0"
                max="40.0"
                className="form-input"
                value={formData.loan_amount_lakh}
                onChange={handleChange}
                required
              />
            </div>

            <div className="form-group">
              <label className="form-label" htmlFor="loan_term">Loan Term (Months)</label>
              <select
                id="loan_term"
                name="loan_term"
                className="form-select"
                value={formData.loan_term}
                onChange={handleChange}
              >
                <option value={12}>12 Months (1 Year)</option>
                <option value={24}>24 Months (2 Years)</option>
                <option value={36}>36 Months (3 Years)</option>
                <option value={48}>48 Months (4 Years)</option>
                <option value={60}>60 Months (5 Years)</option>
                <option value={72}>72 Months (6 Years)</option>
                <option value={84}>84 Months (7 Years)</option>
              </select>
            </div>

            <div className="form-group">
              <label className="form-label" htmlFor="loan_purpose">Loan Purpose</label>
              <select
                id="loan_purpose"
                name="loan_purpose"
                className="form-select"
                value={formData.loan_purpose}
                onChange={handleChange}
              >
                <option value="Personal">Personal</option>
                <option value="Car">Car</option>
                <option value="Business">Business</option>
                <option value="Home">Home</option>
                <option value="Education">Education</option>
              </select>
            </div>

            <div className="form-group">
              <label className="form-label" htmlFor="education_level">Education Level</label>
              <select
                id="education_level"
                name="education_level"
                className="form-select"
                value={formData.education_level}
                onChange={handleChange}
              >
                <option value="Graduate">Graduate</option>
                <option value="Not Graduate">Not Graduate</option>
              </select>
            </div>

            <div className="form-group">
              <label className="form-label" htmlFor="employer_category">Employer Category</label>
              <select
                id="employer_category"
                name="employer_category"
                className="form-select"
                value={formData.employer_category}
                onChange={handleChange}
              >
                <option value="Private">Private</option>
                <option value="Government">Government</option>
                <option value="MNC">MNC</option>
                <option value="Business">Business</option>
                <option value="Unemployed">Unemployed</option>
              </select>
            </div>
          </div>
        </div>

        <div style={{ marginTop: '1.5rem', display: 'flex', justifyContent: 'flex-end' }}>
          <button
            type="submit"
            className="btn btn-primary"
            style={{ padding: '0.75rem 2rem', fontSize: '1rem' }}
            disabled={loading}
          >
            <CreditCard size={18} />
            {loading ? 'Evaluating Application...' : 'Evaluate Application'}
          </button>
        </div>
      </form>
    </div>
  );
};
