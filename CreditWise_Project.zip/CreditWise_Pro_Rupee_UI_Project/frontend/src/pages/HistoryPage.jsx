import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { predictionAPI } from '../api';
import { History, Download, CreditCard, RefreshCw, AlertCircle } from 'lucide-react';

export const HistoryPage = () => {
  const [history, setHistory] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  const fetchHistory = async () => {
    setLoading(true);
    setError(null);
    try {
      const res = await predictionAPI.getHistory();
      setHistory(res.data);
    } catch (err) {
      setError('Unable to load prediction history. Please check your network.');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchHistory();
  }, []);

  const exportCSV = () => {
    if (history.length === 0) return;

    const headers = [
      'ID',
      'Created_At',
      'Decision',
      'Approval_Probability',
      'Loan_Amount_Lakh',
      'Applicant_Income_Rupees',
      'Coapplicant_Income_Rupees',
      'Credit_Score',
      'DTI_Ratio',
      'Savings_Rupees',
      'Collateral_Rupees',
      'Loan_Term',
      'Model_Version',
    ];

    const rows = history.map((item) => [
      item.id,
      item.created_at,
      item.decision_label,
      (item.approval_probability * 100).toFixed(1) + '%',
      item.loan_amount_lakh,
      item.applicant_income_rupees,
      item.coapplicant_income_rupees,
      item.credit_score,
      item.dti_ratio,
      item.savings_rupees,
      item.collateral_value_rupees,
      item.loan_term,
      item.model_version,
    ]);

    const csvContent =
      'data:text/csv;charset=utf-8,' +
      [headers.join(','), ...rows.map((e) => e.join(','))].join('\n');

    const encodedUri = encodeURI(csvContent);
    const link = document.createElement('a');
    link.setAttribute('href', encodedUri);
    link.setAttribute('download', `creditwise_my_history_${new Date().toISOString().slice(0, 10)}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  return (
    <div>
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '1.5rem', flexWrap: 'wrap', gap: '1rem' }}>
        <div>
          <h1 style={{ fontSize: '1.85rem', fontWeight: 800 }}>My Prediction History</h1>
          <p style={{ color: 'var(--text-secondary)', fontSize: '0.92rem' }}>
            Private history for your account. Customer records are strictly isolated.
          </p>
        </div>

        <div style={{ display: 'flex', gap: '0.75rem' }}>
          <button onClick={fetchHistory} className="btn btn-outline btn-sm" disabled={loading}>
            <RefreshCw size={15} /> Refresh
          </button>
          {history.length > 0 && (
            <button onClick={exportCSV} className="btn btn-primary btn-sm">
              <Download size={15} /> Export CSV
            </button>
          )}
        </div>
      </div>

      {error && (
        <div className="alert alert-danger">
          <AlertCircle size={18} style={{ flexShrink: 0 }} />
          <span>{error}</span>
        </div>
      )}

      {loading ? (
        <div className="card" style={{ textAlign: 'center', padding: '3rem' }}>
          <p style={{ color: 'var(--text-secondary)', fontWeight: 600 }}>Loading your history records...</p>
        </div>
      ) : history.length === 0 ? (
        <div className="card" style={{ textAlign: 'center', padding: '3.5rem 1.5rem' }}>
          <History size={48} color="var(--text-muted)" style={{ marginBottom: '1rem' }} />
          <h2 style={{ fontSize: '1.25rem', marginBottom: '0.5rem' }}>No prediction history yet</h2>
          <p style={{ color: 'var(--text-secondary)', maxWidth: '420px', margin: '0 auto 1.5rem', fontSize: '0.9rem' }}>
            Evaluate your first loan application to see probability breakdowns and decision auditing here.
          </p>
          <Link to="/predict" className="btn btn-primary">
            <CreditCard size={18} /> Make First Prediction
          </Link>
        </div>
      ) : (
        <div className="table-container card" style={{ padding: 0 }}>
          <table>
            <thead>
              <tr>
                <th>#</th>
                <th>Date & Time</th>
                <th>Decision</th>
                <th>Approval Prob.</th>
                <th>Loan Amount</th>
                <th>Annual Income</th>
                <th>Credit Score</th>
                <th>DTI Ratio</th>
                <th>Model</th>
              </tr>
            </thead>
            <tbody>
              {history.map((item) => (
                <tr key={item.id}>
                  <td><strong>#{item.id}</strong></td>
                  <td style={{ color: 'var(--text-secondary)', fontSize: '0.82rem' }}>
                    {new Date(item.created_at).toLocaleString('en-IN', {
                      dateStyle: 'medium',
                      timeStyle: 'short',
                    })}
                  </td>
                  <td>
                    {item.prediction === 1 ? (
                      <span className="badge-success">Approved</span>
                    ) : (
                      <span className="badge-danger">Rejected</span>
                    )}
                  </td>
                  <td>
                    <strong style={{ color: item.prediction === 1 ? '#15803d' : '#b91c1c' }}>
                      {(item.approval_probability * 100).toFixed(1)}%
                    </strong>
                  </td>
                  <td>₹{item.loan_amount_lakh} Lakh</td>
                  <td>₹{Number(item.applicant_income_rupees).toLocaleString('en-IN')}</td>
                  <td>{item.credit_score}</td>
                  <td>{(item.dti_ratio * 100).toFixed(0)}%</td>
                  <td style={{ fontSize: '0.78rem', color: 'var(--text-muted)' }}>
                    {item.model_version.split('-')[0]}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
};
