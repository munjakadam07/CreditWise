import React from 'react';
import { Link } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import { MetricCard } from '../components/MetricCard';
import { CheckCircle2, ShieldCheck, Cpu, ArrowRight, AlertTriangle, Database } from 'lucide-react';

export const LandingPage = () => {
  const { isAuthenticated } = useAuth();

  return (
    <div>
      <div className="hero-banner">
        <div style={{ display: 'inline-flex', alignItems: 'center', gap: '0.5rem', background: 'rgba(255,255,255,0.12)', padding: '0.35rem 0.85rem', borderRadius: '9999px', fontSize: '0.85rem', marginBottom: '1rem' }}>
          <Cpu size={16} /> Enterprise ML Loan Intelligence
        </div>
        <h1>CreditWise Loan Approval System</h1>
        <p>
          Next-generation underwriting evaluation powered by Gradient Boosting machine learning,
          native Indian Rupee financial scaling, Argon2id authentication, and explainable AI insights.
        </p>

        <div style={{ display: 'flex', gap: '1rem', marginTop: '1.75rem', flexWrap: 'wrap' }}>
          <Link to={isAuthenticated ? '/predict' : '/register'} className="btn" style={{ background: '#ffffff', color: '#0f172a', fontWeight: 700 }}>
            {isAuthenticated ? 'Make a Prediction (₹)' : 'Create Free Account'} <ArrowRight size={18} />
          </Link>
          <Link to={isAuthenticated ? '/history' : '/login'} className="btn btn-outline" style={{ color: '#ffffff', borderColor: 'rgba(255,255,255,0.3)' }}>
            {isAuthenticated ? 'View Prediction History' : 'Sign In'}
          </Link>
        </div>
      </div>

      <div className="grid-4" style={{ marginBottom: '2.5rem' }}>
        <MetricCard
          title="Labeled Records"
          value="950"
          subtitle="Supervised training dataset"
          icon={Database}
          color="#2563eb"
        />
        <MetricCard
          title="Holdout Accuracy"
          value="95.8%"
          subtitle="Gradient Boosting validation"
          icon={CheckCircle2}
          color="#10b981"
        />
        <MetricCard
          title="Holdout ROC-AUC"
          value="98.8%"
          subtitle="Verified decision separation"
          icon={Cpu}
          color="#8b5cf6"
        />
        <MetricCard
          title="Security Standard"
          value="Argon2id"
          subtitle="Memory-hard password hashing"
          icon={ShieldCheck}
          color="#f59e0b"
        />
      </div>

      <div className="card" style={{ marginBottom: '2rem' }}>
        <h2 style={{ fontSize: '1.35rem', marginBottom: '1rem', color: 'var(--text-primary)' }}>
          Why CreditWise?
        </h2>
        <div className="grid-3">
          <div>
            <h3 style={{ fontSize: '1.05rem', color: 'var(--primary)', marginBottom: '0.4rem' }}>
              🇮🇳 Native Indian Rupee UI
            </h3>
            <p style={{ fontSize: '0.88rem', color: 'var(--text-secondary)' }}>
              Enter annual income, savings, collateral, and loan amounts in standard Indian Rupees (₹) and Lakhs.
              The system handles model transformations with mathematical precision.
            </p>
          </div>
          <div>
            <h3 style={{ fontSize: '1.05rem', color: 'var(--primary)', marginBottom: '0.4rem' }}>
              🛡️ Out-of-Distribution Safety
            </h3>
            <p style={{ fontSize: '0.88rem', color: 'var(--text-secondary)' }}>
              Inputs outside observed historical training bounds are blocked rather than silently extrapolated,
              preventing hallucinated decisions on unrealistic financial figures.
            </p>
          </div>
          <div>
            <h3 style={{ fontSize: '1.05rem', color: 'var(--primary)', marginBottom: '0.4rem' }}>
              📊 Transparent Model Auditing
            </h3>
            <p style={{ fontSize: '0.88rem', color: 'var(--text-secondary)' }}>
              Compare Gradient Boosting, Random Forest, and Logistic Regression on identical holdout samples
              with genuine confusion matrices and ROC curves.
            </p>
          </div>
        </div>
      </div>

      <div className="alert alert-warning" style={{ alignItems: 'center' }}>
        <AlertTriangle size={24} style={{ flexShrink: 0 }} />
        <div>
          <strong>Academic Prototype Notice:</strong>
          {' '}The predictions provided by CreditWise reflect statistical patterns learned from a synthetic benchmark dataset.
          A high approval probability does not constitute a legal commitment or guaranteed lending decision by any financial institution.
        </div>
      </div>
    </div>
  );
};
