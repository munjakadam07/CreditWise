import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import { predictionAPI } from '../api';
import { MetricCard } from '../components/MetricCard';
import { CreditCard, History, CheckCircle2, XCircle, ArrowRight, User } from 'lucide-react';

export const CustomerDashboard = () => {
  const { user } = useAuth();
  const [recent, setRecent] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const load = async () => {
      try {
        const res = await predictionAPI.getHistory();
        setRecent(res.data.slice(0, 5));
      } catch (e) {
        console.error(e);
      } finally {
        setLoading(false);
      }
    };
    load();
  }, []);

  const approvedCount = recent.filter((r) => r.prediction === 1).length;
  const rejectedCount = recent.length - approvedCount;

  return (
    <div>
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '2rem', flexWrap: 'wrap', gap: '1rem' }}>
        <div>
          <h1 style={{ fontSize: '1.85rem', fontWeight: 800 }}>Customer Dashboard</h1>
          <p style={{ color: 'var(--text-secondary)', fontSize: '0.92rem' }}>
            Welcome back, <strong>{user?.full_name}</strong> ({user?.email})
          </p>
        </div>

        <Link to="/predict" className="btn btn-primary">
          <CreditCard size={18} /> New Prediction (₹)
        </Link>
      </div>

      <div className="grid-3" style={{ marginBottom: '2rem' }}>
        <MetricCard
          title="Account Role"
          value={user?.role?.toUpperCase()}
          subtitle="Customer Account Status"
          icon={User}
          color="#2563eb"
        />
        <MetricCard
          title="Recent Approvals"
          value={approvedCount}
          subtitle="From your recent evaluations"
          icon={CheckCircle2}
          color="#16a34a"
        />
        <MetricCard
          title="Recent Rejections"
          value={rejectedCount}
          subtitle="From your recent evaluations"
          icon={XCircle}
          color="#dc2626"
        />
      </div>

      <div className="card">
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '1.25rem' }}>
          <h2 style={{ fontSize: '1.2rem', fontWeight: 800 }}>Recent Evaluations</h2>
          <Link to="/history" style={{ fontSize: '0.85rem', fontWeight: 600, display: 'flex', alignItems: 'center', gap: '0.3rem' }}>
            View full history <ArrowRight size={14} />
          </Link>
        </div>

        {loading ? (
          <p style={{ color: 'var(--text-secondary)' }}>Loading history...</p>
        ) : recent.length === 0 ? (
          <div style={{ textAlign: 'center', padding: '2rem 1rem' }}>
            <p style={{ color: 'var(--text-secondary)', marginBottom: '1rem' }}>You have not evaluated any loan applications yet.</p>
            <Link to="/predict" className="btn btn-primary btn-sm">
              <CreditCard size={16} /> Run First Evaluation
            </Link>
          </div>
        ) : (
          <div className="table-container">
            <table>
              <thead>
                <tr>
                  <th>#</th>
                  <th>Date</th>
                  <th>Loan Amount</th>
                  <th>Annual Income</th>
                  <th>Credit Score</th>
                  <th>Approval Prob.</th>
                  <th>Status</th>
                </tr>
              </thead>
              <tbody>
                {recent.map((item) => (
                  <tr key={item.id}>
                    <td>#{item.id}</td>
                    <td>{new Date(item.created_at).toLocaleDateString('en-IN')}</td>
                    <td>₹{item.loan_amount_lakh} Lakh</td>
                    <td>₹{Number(item.applicant_income_rupees).toLocaleString('en-IN')}</td>
                    <td>{item.credit_score}</td>
                    <td>{(item.approval_probability * 100).toFixed(1)}%</td>
                    <td>
                      {item.prediction === 1 ? (
                        <span className="badge-success">Approved</span>
                      ) : (
                        <span className="badge-danger">Rejected</span>
                      )}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </div>
  );
};
