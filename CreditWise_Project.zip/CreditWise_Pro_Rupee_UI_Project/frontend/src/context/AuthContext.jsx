import React, { createContext, useContext, useState, useEffect } from 'react';
import { authAPI } from '../api';

const AuthContext = createContext(null);

export const AuthProvider = ({ children }) => {
  const [user, setUser] = useState(() => {
    const saved = localStorage.getItem('creditwise_user');
    return saved ? JSON.parse(saved) : null;
  });
  const [token, setToken] = useState(() => localStorage.getItem('creditwise_token') || null);
  const [loading, setLoading] = useState(true);

  // Validate session on mount
  useEffect(() => {
    const verifySession = async () => {
      const storedToken = localStorage.getItem('creditwise_token');
      if (storedToken) {
        try {
          const res = await authAPI.getMe();
          setUser(res.data);
          localStorage.setItem('creditwise_user', JSON.stringify(res.data));
        } catch (err) {
          console.warn('Session expired or invalid:', err);
          logout();
        }
      }
      setLoading(false);
    };
    verifySession();
  }, []);

  const login = async (email, password) => {
    const res = await authAPI.login({ email, password });
    const { access_token, user: userProfile } = res.data;
    localStorage.setItem('creditwise_token', access_token);
    localStorage.setItem('creditwise_user', JSON.stringify(userProfile));
    setToken(access_token);
    setUser(userProfile);
    return userProfile;
  };

  const adminLogin = async (username, password) => {
    const res = await authAPI.adminLogin({ username, password });
    const { access_token, user: userProfile } = res.data;
    localStorage.setItem('creditwise_token', access_token);
    localStorage.setItem('creditwise_user', JSON.stringify(userProfile));
    setToken(access_token);
    setUser(userProfile);
    return userProfile;
  };

  const register = async (email, password, full_name) => {
    const res = await authAPI.register({ email, password, full_name });
    const { access_token, user: userProfile } = res.data;
    localStorage.setItem('creditwise_token', access_token);
    localStorage.setItem('creditwise_user', JSON.stringify(userProfile));
    setToken(access_token);
    setUser(userProfile);
    return userProfile;
  };

  const logout = () => {
    localStorage.removeItem('creditwise_token');
    localStorage.removeItem('creditwise_user');
    setToken(null);
    setUser(null);
  };

  const isAuthenticated = !!token && !!user;
  const isAdmin = user?.role === 'admin';

  return (
    <AuthContext.Provider
      value={{
        user,
        token,
        isAuthenticated,
        isAdmin,
        loading,
        login,
        adminLogin,
        register,
        logout,
      }}
    >
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => {
  const ctx = useContext(AuthContext);
  if (!ctx) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return ctx;
};
