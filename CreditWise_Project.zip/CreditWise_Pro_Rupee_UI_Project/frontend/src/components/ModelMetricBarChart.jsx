import React from 'react';
import {
  BarChart,
  Bar,
  Cell,
  ErrorBar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  LabelList,
  ResponsiveContainer,
} from 'recharts';
import {
  VERIFIED_MODELS_FALLBACK,
  buildMetricChartData,
} from './metricChartUtils';

export { VERIFIED_MODELS_FALLBACK, buildMetricChartData };

/**
 * Custom Tooltip rendering percentage and standard-deviation error bounds.
 */
const CustomBarTooltip = ({ active, payload, title, hasErrorBars }) => {
  if (active && payload && payload.length) {
    const d = payload[0].payload;
    return (
      <div
        style={{
          backgroundColor: '#ffffff',
          padding: '0.65rem 0.9rem',
          border: '1px solid #cbd5e1',
          borderRadius: '8px',
          boxShadow: '0 4px 6px -1px rgba(0, 0, 0, 0.1)',
          fontSize: '0.82rem',
          zIndex: 10,
        }}
      >
        <div style={{ fontWeight: 700, color: d.fill, marginBottom: '0.25rem', display: 'flex', alignItems: 'center', gap: '0.35rem' }}>
          <span>{d.model}</span>
          {d.isProduction && (
            <span
              style={{
                fontSize: '0.68rem',
                backgroundColor: '#eff6ff',
                color: '#2563eb',
                border: '1px solid #bfdbfe',
                padding: '0.05rem 0.35rem',
                borderRadius: '4px',
              }}
            >
              Active Production
            </span>
          )}
        </div>
        <div style={{ color: '#0f172a' }}>
          <strong>{title}:</strong> {d.displayValue}
        </div>
        {hasErrorBars && d.error != null && (
          <div style={{ color: '#475569', fontSize: '0.78rem', marginTop: '0.2rem' }}>
            Cross-Val Std Dev: <strong>±{d.error}%</strong>
          </div>
        )}
      </div>
    );
  }
  return null;
};

/**
 * Individual comparative bar chart component for 3-model benchmark metrics.
 */
export const ModelMetricBarChart = ({
  title,
  subtitle,
  badgeText = 'Holdout Metric',
  badgeColor = '#eff6ff',
  badgeTextColor = '#2563eb',
  data,
  hasErrorBars = false,
}) => {
  return (
    <div
      className="card"
      style={{
        padding: '1.25rem',
        display: 'flex',
        flexDirection: 'column',
        justifyContent: 'space-between',
        borderRadius: '12px',
        border: '1px solid var(--border)',
        boxShadow: 'var(--shadow-sm)',
      }}
    >
      {/* Header */}
      <div style={{ marginBottom: '0.75rem' }}>
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', gap: '0.5rem', marginBottom: '0.25rem' }}>
          <h4 style={{ fontSize: '1rem', fontWeight: 800, color: 'var(--text-primary)', margin: 0 }}>
            {title}
          </h4>
          <span
            style={{
              fontSize: '0.7rem',
              fontWeight: 700,
              padding: '0.15rem 0.5rem',
              borderRadius: '9999px',
              backgroundColor: badgeColor,
              color: badgeTextColor,
              whiteSpace: 'nowrap',
            }}
          >
            {badgeText}
          </span>
        </div>
        {subtitle && (
          <p style={{ fontSize: '0.8rem', color: 'var(--text-secondary)', margin: 0 }}>
            {subtitle}
          </p>
        )}
      </div>

      {/* Chart Canvas */}
      <div style={{ width: '100%', height: 260 }}>
        <ResponsiveContainer>
          <BarChart
            data={data}
            margin={{ top: 25, right: 15, left: -12, bottom: 20 }}
          >
            <CartesianGrid strokeDasharray="3 3" stroke="#f1f5f9" vertical={false} />
            <XAxis
              dataKey="model"
              interval={0}
              tick={{ fontSize: 11, fill: '#334155', fontWeight: 600 }}
              axisLine={{ stroke: '#cbd5e1' }}
              tickLine={{ stroke: '#cbd5e1' }}
            />
            <YAxis
              domain={[0, 100]}
              ticks={[0, 20, 40, 60, 80, 100]}
              tickFormatter={(v) => `${v}%`}
              tick={{ fontSize: 10, fill: '#64748b' }}
              axisLine={{ stroke: '#cbd5e1' }}
              tickLine={{ stroke: '#cbd5e1' }}
            />
            <Tooltip
              content={<CustomBarTooltip title={title} hasErrorBars={hasErrorBars} />}
            />
            <Bar
              dataKey="score"
              radius={[4, 4, 0, 0]}
              maxBarSize={48}
            >
              {data.map((entry, index) => (
                <Cell key={`cell-${index}`} fill={entry.fill} />
              ))}
              {hasErrorBars && (
                <ErrorBar
                  dataKey="error"
                  width={6}
                  strokeWidth={2}
                  stroke="#0f172a"
                />
              )}
              <LabelList
                dataKey="displayValue"
                position="top"
                offset={hasErrorBars ? 15 : 6}
                fill="#0f172a"
                fontSize={11}
                fontWeight={700}
              />
            </Bar>
          </BarChart>
        </ResponsiveContainer>
      </div>

      {/* Summary Footer */}
      <div
        style={{
          borderTop: '1px solid #f1f5f9',
          paddingTop: '0.65rem',
          marginTop: '0.25rem',
          display: 'flex',
          justifyContent: 'space-between',
          alignItems: 'center',
          flexWrap: 'wrap',
          gap: '0.5rem',
          fontSize: '0.75rem',
          color: 'var(--text-secondary)',
        }}
      >
        {data.map((d, idx) => (
          <span key={idx} style={{ display: 'inline-flex', alignItems: 'center', gap: '0.3rem' }}>
            <span style={{ width: 8, height: 8, borderRadius: '50%', backgroundColor: d.fill }} />
            <strong style={{ color: '#0f172a' }}>{d.model.split(' ')[0]}:</strong>{' '}
            {d.displayValue}
            {hasErrorBars && d.error != null && (
              <span style={{ color: '#64748b', fontSize: '0.7rem' }}> (±{d.error}%)</span>
            )}
          </span>
        ))}
      </div>
    </div>
  );
};
