import React from 'react';
import {
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ResponsiveContainer,
} from 'recharts';

export const RocCurveChart = ({ rocData }) => {
  if (!rocData) return null;

  // Combine points from all three models on common false-positive-rate grid for smooth plotting
  const sampleFprs = [0, 0.02, 0.05, 0.1, 0.15, 0.2, 0.3, 0.4, 0.5, 0.6, 0.7, 0.8, 0.9, 1.0];

  const getTprAtFpr = (points, targetFpr) => {
    if (!points || points.length === 0) return targetFpr;
    // Find closest point
    let closest = points[0];
    let minDiff = Math.abs(points[0].fpr - targetFpr);
    for (const pt of points) {
      const diff = Math.abs(pt.fpr - targetFpr);
      if (diff < minDiff) {
        minDiff = diff;
        closest = pt;
      }
    }
    return closest.tpr;
  };

  const chartData = sampleFprs.map((fpr) => {
    return {
      fpr: fpr,
      gradient_boosting: getTprAtFpr(rocData.gradient_boosting?.points, fpr),
      random_forest: getTprAtFpr(rocData.random_forest?.points, fpr),
      logistic_regression: getTprAtFpr(rocData.logistic_regression?.points, fpr),
      random_chance: fpr,
    };
  });

  return (
    <div style={{ width: '100%', height: 340 }}>
      <ResponsiveContainer>
        <LineChart data={chartData} margin={{ top: 10, right: 20, left: 0, bottom: 20 }}>
          <CartesianGrid strokeDasharray="3 3" stroke="#e2e8f0" />
          <XAxis
            dataKey="fpr"
            type="number"
            domain={[0, 1]}
            tickFormatter={(v) => v.toFixed(2)}
            label={{ value: 'False Positive Rate (1 - Specificity)', position: 'insideBottom', offset: -12 }}
          />
          <YAxis
            type="number"
            domain={[0, 1]}
            tickFormatter={(v) => v.toFixed(2)}
            label={{ value: 'True Positive Rate (Sensitivity)', angle: -90, position: 'insideLeft', offset: 12 }}
          />
          <Tooltip
            formatter={(value, name) => [value.toFixed(4), name]}
            labelFormatter={(label) => `FPR: ${Number(label).toFixed(2)}`}
          />
          <Legend verticalAlign="top" height={36} />
          <Line
            type="monotone"
            dataKey="gradient_boosting"
            name={`Gradient Boosting (AUC: ${rocData.gradient_boosting?.roc_auc || '0.988'})`}
            stroke="#2563eb"
            strokeWidth={3}
            dot={{ r: 3 }}
          />
          <Line
            type="monotone"
            dataKey="random_forest"
            name={`Random Forest (AUC: ${rocData.random_forest?.roc_auc || '0.985'})`}
            stroke="#10b981"
            strokeWidth={2}
            dot={{ r: 2 }}
          />
          <Line
            type="monotone"
            dataKey="logistic_regression"
            name={`Logistic Regression (AUC: ${rocData.logistic_regression?.roc_auc || '0.921'})`}
            stroke="#f59e0b"
            strokeWidth={2}
            dot={{ r: 2 }}
          />
          <Line
            type="monotone"
            dataKey="random_chance"
            name="Random Baseline (AUC: 0.50)"
            stroke="#94a3b8"
            strokeDasharray="5 5"
            strokeWidth={1}
            dot={false}
          />
        </LineChart>
      </ResponsiveContainer>
    </div>
  );
};
