import React from 'react';
import { Link, NavLink, useNavigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import { CreditCard, History, ShieldAlert, LogOut, User, BarChart3, Home } from 'lucide-react';

export const Navbar = () => {
  const { user, isAuthenticated, isAdmin, logout } = useAuth();
  const navigate = useNavigate();

  const handleLogout = () => {
    logout();
    navigate('/login');
  };

  return (
    <nav className="navbar">
      <div className="navbar-inner">
        <Link to="/" className="brand">
          <CreditCard size={24} color="var(--primary)" />
          <span>CreditWise</span>
          <span className="badge">PRO</span>
        </Link>

        <div className="nav-links">
          <NavLink to="/" className={({ isActive }) => `nav-link ${isActive ? 'active' : ''}`} end>
            <Home size={17} /> Overview
          </NavLink>

          {isAuthenticated ? (
            <>
              <NavLink to="/predict" className={({ isActive }) => `nav-link ${isActive ? 'active' : ''}`}>
                <CreditCard size={17} /> Predict (₹)
              </NavLink>

              <NavLink to="/history" className={({ isActive }) => `nav-link ${isActive ? 'active' : ''}`}>
                <History size={17} /> History
              </NavLink>

              {isAdmin && (
                <NavLink to="/admin" className={({ isActive }) => `nav-link ${isActive ? 'active' : ''}`}>
                  <ShieldAlert size={17} color="#dc2626" /> Admin Portal
                </NavLink>
              )}

              <div style={{ display: 'flex', alignItems: 'center', gap: '0.6rem', marginLeft: '0.5rem' }}>
                <span className="badge-neutral" style={{ display: 'flex', alignItems: 'center', gap: '0.3rem' }}>
                  <User size={13} /> {user?.full_name?.split(' ')[0] || user?.email}
                </span>

                <button onClick={handleLogout} className="btn btn-outline btn-sm" title="Log out">
                  <LogOut size={15} /> Logout
                </button>
              </div>
            </>
          ) : (
            <>
              <NavLink to="/login" className={({ isActive }) => `nav-link ${isActive ? 'active' : ''}`}>
                Login
              </NavLink>
              <Link to="/register" className="btn btn-primary btn-sm">
                Get Started
              </Link>
            </>
          )}
        </div>
      </div>
    </nav>
  );
};
