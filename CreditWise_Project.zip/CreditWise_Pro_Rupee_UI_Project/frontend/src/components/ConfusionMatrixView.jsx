import React from 'react';

export const ConfusionMatrixView = ({ data }) => {
  if (!data) return <p style={{ color: 'var(--text-muted)' }}>No confusion matrix data available.</p>;

  const { true_negatives: tn, false_positives: fp, false_negatives: fn, true_positives: tp, sample_count: total } = data;

  const pct = (val) => ((val / total) * 100).toFixed(1);

  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: '0.75rem' }}>
      <div style={{ display: 'grid', gridTemplateColumns: '120px 1fr 1fr', gap: '8px', textAlign: 'center', fontSize: '0.85rem' }}>
        <div></div>
        <div style={{ fontWeight: 700, color: 'var(--text-secondary)' }}>Pred: Rejected (0)</div>
        <div style={{ fontWeight: 700, color: 'var(--text-secondary)' }}>Pred: Approved (1)</div>

        <div style={{ fontWeight: 700, color: 'var(--text-secondary)', display: 'flex', alignItems: 'center', justifyContent: 'flex-end', paddingRight: '8px' }}>
          Actual: Rejected
        </div>
        <div style={{ background: '#ecfdf5', border: '1px solid #a7f3d0', padding: '1rem', borderRadius: '8px' }}>
          <div style={{ fontSize: '1.25rem', fontWeight: 800, color: '#065f46' }}>{tn}</div>
          <div style={{ fontSize: '0.75rem', color: '#047857' }}>True Negative ({pct(tn)}%)</div>
        </div>
        <div style={{ background: '#fef2f2', border: '1px solid #fecaca', padding: '1rem', borderRadius: '8px' }}>
          <div style={{ fontSize: '1.25rem', fontWeight: 800, color: '#991b1b' }}>{fp}</div>
          <div style={{ fontSize: '0.75rem', color: '#b91c1c' }}>False Positive ({pct(fp)}%)</div>
        </div>

        <div style={{ fontWeight: 700, color: 'var(--text-secondary)', display: 'flex', alignItems: 'center', justifyContent: 'flex-end', paddingRight: '8px' }}>
          Actual: Approved
        </div>
        <div style={{ background: '#fef2f2', border: '1px solid #fecaca', padding: '1rem', borderRadius: '8px' }}>
          <div style={{ fontSize: '1.25rem', fontWeight: 800, color: '#991b1b' }}>{fn}</div>
          <div style={{ fontSize: '0.75rem', color: '#b91c1c' }}>False Negative ({pct(fn)}%)</div>
        </div>
        <div style={{ background: '#ecfdf5', border: '1px solid #a7f3d0', padding: '1rem', borderRadius: '8px' }}>
          <div style={{ fontSize: '1.25rem', fontWeight: 800, color: '#065f46' }}>{tp}</div>
          <div style={{ fontSize: '0.75rem', color: '#047857' }}>True Positive ({pct(tp)}%)</div>
        </div>
      </div>
      <div style={{ fontSize: '0.75rem', color: 'var(--text-muted)', textAlign: 'center', marginTop: '0.25rem' }}>
        Total holdout test samples: {total} (130 actual rejected, 60 actual approved)
      </div>
    </div>
  );
};
