/**
 * Model Metric Chart Utilities and Verified Holdout Fallback Definitions.
 *
 * Ground truth benchmark values verified on 80/20 holdout split (190 test samples)
 * from data/verified_model_metrics.json.
 */

export const VERIFIED_MODELS_FALLBACK = [
  {
    model_key: 'gradient_boosting',
    model_name: 'Gradient Boosting Classifier',
    short_name: 'Gradient Boosting',
    accuracy: 0.9579,
    precision: 0.9062,
    recall: 0.9667,
    f1_score: 0.9355,
    roc_auc: 0.9877,
    cv_mean_accuracy: 0.9579,
    cv_std_accuracy: 0.0088,
    cv_mean_roc_auc: 0.9877,
    cv_std_roc_auc: 0.0054,
    fill: '#2563eb', // Active production primary blue
    isProduction: true,
  },
  {
    model_key: 'random_forest',
    model_name: 'Random Forest Classifier',
    short_name: 'Random Forest',
    accuracy: 0.9316,
    precision: 0.8852,
    recall: 0.9000,
    f1_score: 0.8926,
    roc_auc: 0.9852,
    cv_mean_accuracy: 0.9411,
    cv_std_accuracy: 0.0052,
    cv_mean_roc_auc: 0.9800,
    cv_std_roc_auc: 0.0054,
    fill: '#10b981', // Benchmark green
    isProduction: false,
  },
  {
    model_key: 'logistic_regression',
    model_name: 'Logistic Regression',
    short_name: 'Logistic Regression',
    accuracy: 0.8842,
    precision: 0.8519,
    recall: 0.7667,
    f1_score: 0.8070,
    roc_auc: 0.9206,
    cv_mean_accuracy: 0.8516,
    cv_std_accuracy: 0.0171,
    cv_mean_roc_auc: 0.9240,
    cv_std_roc_auc: 0.0079,
    fill: '#f59e0b', // Benchmark amber
    isProduction: false,
  },
];

/**
 * Builds data array for a specific metric across all 3 ML models.
 * Prioritizes live model comparison results from the API, falling back to
 * exact verified holdout evaluation artifacts from data/verified_model_metrics.json.
 */
export const buildMetricChartData = (modelsList, metricKey, errorKey = null) => {
  return VERIFIED_MODELS_FALLBACK.map((fallback) => {
    const matched = modelsList?.find((m) => {
      if (m.model_key && m.model_key === fallback.model_key) return true;
      const name = (m.model_name || '').toLowerCase();
      if (fallback.model_key === 'gradient_boosting' && name.includes('gradient')) return true;
      if (fallback.model_key === 'random_forest' && name.includes('forest')) return true;
      if (fallback.model_key === 'logistic_regression' && name.includes('logistic')) return true;
      return false;
    });

    const rawVal = matched?.[metricKey] != null ? matched[metricKey] : fallback[metricKey];
    const score = Number((rawVal * 100).toFixed(2));

    let error = null;
    if (errorKey) {
      const rawErr = matched?.[errorKey] != null ? matched[errorKey] : fallback[errorKey];
      if (rawErr != null) {
        error = Number((rawErr * 100).toFixed(2));
      }
    }

    return {
      model: fallback.short_name,
      modelKey: fallback.model_key,
      score: score,
      displayValue: `${score.toFixed(2)}%`,
      error: error,
      fill: fallback.fill,
      isProduction: fallback.isProduction,
    };
  });
};
