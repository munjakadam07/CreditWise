
import os, sqlite3, hashlib, json
from datetime import datetime
from pathlib import Path
import joblib, numpy as np, pandas as pd, streamlit as st
import matplotlib.pyplot as plt

APP_DIR=Path(__file__).resolve().parent
MODEL_PATH=APP_DIR/"creditwise_model.joblib"
DATA_PATH=APP_DIR/"loan_approval_data.csv"
RANGE_PATH=APP_DIR/"feature_ranges.json"
META_PATH=APP_DIR/"model_metadata.json"
DB_PATH=APP_DIR/"creditwise.db"

st.set_page_config(page_title="CreditWise | Loan Intelligence",page_icon="💳",layout="wide")

st.markdown("""
<style>
.block-container{padding-top:1.2rem}
.hero{padding:1.5rem;border-radius:18px;background:linear-gradient(135deg,#0f172a,#1d4ed8);color:white;margin-bottom:1rem}
.hero h1{margin:0}.hero p{margin:.3rem 0 0;opacity:.85}
.good{padding:1rem;border-radius:14px;background:#ecfdf5;border:1px solid #a7f3d0}
.bad{padding:1rem;border-radius:14px;background:#fef2f2;border:1px solid #fecaca}
</style>
""",unsafe_allow_html=True)

@st.cache_resource
def load_model(): return joblib.load(MODEL_PATH)
@st.cache_data
def load_data(): return pd.read_csv(DATA_PATH)
@st.cache_data
def load_meta(): return json.loads(META_PATH.read_text())
@st.cache_data
def load_ranges(): return json.loads(RANGE_PATH.read_text())

model=load_model(); data=load_data(); meta=load_meta(); ranges=load_ranges()

def db():
    con=sqlite3.connect(DB_PATH,check_same_thread=False)
    con.execute("""CREATE TABLE IF NOT EXISTS predictions(
    id INTEGER PRIMARY KEY AUTOINCREMENT, created_at TEXT,
    applicant_income REAL, coapplicant_income REAL, employment_status TEXT,
    age REAL, marital_status TEXT, dependents REAL, credit_score REAL,
    existing_loans REAL, dti_ratio REAL, savings REAL, collateral_value REAL,
    loan_amount REAL, loan_term REAL, loan_purpose TEXT, property_area TEXT,
    education_level TEXT, gender TEXT, employer_category TEXT,
    approval_probability REAL, prediction INTEGER)""")
    con.commit(); return con

def save(row,p,decision):
    con=db()
    cols=list(row.keys())
    con.execute("""INSERT INTO predictions(
    created_at,applicant_income,coapplicant_income,employment_status,age,
    marital_status,dependents,credit_score,existing_loans,dti_ratio,savings,
    collateral_value,loan_amount,loan_term,loan_purpose,property_area,
    education_level,gender,employer_category,approval_probability,prediction)
    VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)""",(
        datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
        row["Applicant_Income"],row["Coapplicant_Income"],row["Employment_Status"],
        row["Age"],row["Marital_Status"],row["Dependents"],row["Credit_Score"],
        row["Existing_Loans"],row["DTI_Ratio"],row["Savings"],row["Collateral_Value"],
        row["Loan_Amount"],row["Loan_Term"],row["Loan_Purpose"],row["Property_Area"],
        row["Education_Level"],row["Gender"],row["Employer_Category"],p,decision))
    con.commit(); con.close()

def history():
    con=db(); x=pd.read_sql_query("SELECT * FROM predictions ORDER BY id DESC",con)
    con.close(); return x

def in_training_range(row):
    problems=[]
    for c, r in ranges.items():
        if c == "Loan_Amount":
            continue
        v=float(row[c])
        if v<r["min"] or v>r["max"]:
            problems.append(f"{c}: value outside the supported application range")
    return problems

st.sidebar.title("💳 CreditWise")
page=st.sidebar.radio("Navigation",["🏠 Overview","🔮 Predict","🧠 Explainability","📊 Dashboard","🗂️ History","🔐 Admin"])

st.markdown('<div class="hero"><h1>CreditWise</h1><p>Explainable ML-based loan approval prediction</p></div>',unsafe_allow_html=True)

if page=="🏠 Overview":
    a,b,c,d=st.columns(4)
    a.metric("Labeled records",f"{meta['training_rows']:,}")
    b.metric("Approved",f"{meta['approved_rows']:,}")
    c.metric("Rejected",f"{meta['rejected_rows']:,}")
    d.metric("5-fold ROC-AUC",f"{meta['five_fold_cv_mean']['roc_auc']:.1%}")
    st.info("50 records in the supplied CSV have no Loan_Approved label. They are excluded from model training rather than treated as rejected.")
    st.markdown("### Validation results")
    st.dataframe(pd.DataFrame([meta["test_metrics"],meta["five_fold_cv_mean"]],index=["Holdout","5-fold CV"]).style.format("{:.1%}"),use_container_width=True)

elif page=="🔮 Predict":
    st.markdown("### New loan application")
    st.caption("Inputs outside the observed training-data range are blocked to prevent unreliable out-of-distribution predictions.")

    with st.form("form"):
        c1,c2,c3=st.columns(3)
        with c1:
            ai_rupees=st.number_input("Applicant Income (₹)",min_value=0.0,max_value=2_000_000.0,value=1_000_000.0,step=10_000.0)
            age=st.number_input("Age",21.0,59.0,30.0,1.0)
            dep=st.number_input("Dependents",0.0,3.0,0.0,1.0)
            gender=st.selectbox("Gender",["Male","Female"])
            marital=st.selectbox("Marital Status",["Married","Single"])
        with c2:
            cai_rupees=st.number_input("Coapplicant Income (₹)",min_value=0.0,max_value=2_000_000.0,value=300_000.0,step=10_000.0)
            credit=st.number_input("Credit Score",550.0,799.0,700.0,1.0)
            loans=st.number_input("Existing Loans",0.0,4.0,1.0,1.0)
            dti=st.number_input("DTI Ratio",0.10,0.60,0.30,0.01,format="%.2f")
            savings_rupees=st.number_input("Savings (₹)",min_value=0.0,max_value=2_000_000.0,value=1_000_000.0,step=10_000.0)
        with c3:
            collateral_rupees=st.number_input("Collateral Value (₹)",min_value=0.0,max_value=5_000_000.0,value=3_000_000.0,step=50_000.0)
            loan_rupees_lakh=st.number_input("Loan Amount (₹ lakh)",min_value=1.0,max_value=40.0,value=20.0,step=0.5)
            term=st.selectbox("Loan Term (months)",[12,24,36,48,60,72,84])
            purpose=st.selectbox("Loan Purpose",["Personal","Car","Business","Home","Education"])
        c1,c2,c3=st.columns(3)
        with c1: emp=st.selectbox("Employment Status",["Salaried","Self-employed","Contract","Unemployed"])
        with c2: area=st.selectbox("Property Area",["Urban","Semiurban","Rural"])
        with c3:
            edu=st.selectbox("Education Level",["Graduate","Not Graduate"])
            employer=st.selectbox("Employer Category",["Private","Government","MNC","Business","Unemployed"])
        go=st.form_submit_button("🚀 Evaluate Application",use_container_width=True)

    if go:
        # Convert the user-facing rupee values to the scale used by the trained model.
        loan=loan_rupees_lakh*1000.0
        ai=ai_rupees/100.0
        cai=cai_rupees/100.0
        savings=savings_rupees/100.0
        collateral=collateral_rupees/100.0
        row={
        "Applicant_Income":ai,"Coapplicant_Income":cai,"Employment_Status":emp,"Age":age,
        "Marital_Status":marital,"Dependents":dep,"Credit_Score":credit,"Existing_Loans":loans,
        "DTI_Ratio":dti,"Savings":savings,"Collateral_Value":collateral,"Loan_Amount":loan,
        "Loan_Term":term,"Loan_Purpose":purpose,"Property_Area":area,"Education_Level":edu,
        "Gender":gender,"Employer_Category":employer}
        inp=pd.DataFrame([row])
        bad=in_training_range(row)
        if bad:
            st.error("Prediction blocked because the input is outside the training-data range.")
            st.write(bad)
        else:
            p=float(model.predict_proba(inp)[0,1]); dec=int(p>=0.50)
            save(row,p,dec)
            if dec:
                st.markdown(f'<div class="good"><h2>✅ Likely Approved</h2><p>Approval probability: <b>{p:.1%}</b></p></div>',unsafe_allow_html=True)
            else:
                st.markdown(f'<div class="bad"><h2>❌ Likely Rejected</h2><p>Approval probability: <b>{p:.1%}</b></p></div>',unsafe_allow_html=True)
            x,y,z=st.columns(3)
            x.metric("Approval Probability",f"{p:.1%}")
            y.metric("Rejection Probability",f"{1-p:.1%}")
            z.metric("Decision Threshold","50%")
            st.progress(p)

elif page=="🧠 Explainability":
    st.markdown("### Why does the model make its prediction?")
    pre=model.named_steps["preprocessor"]; clf=model.named_steps["model"]
    names=pre.get_feature_names_out(); imp=clf.feature_importances_
    ex=pd.DataFrame({"Feature":names,"Importance":imp}).sort_values("Importance",ascending=False).head(15)
    ex["Feature"]=ex["Feature"].str.replace("numeric__","",regex=False).str.replace("categorical__","",regex=False)
    fig,ax=plt.subplots(figsize=(9,6)); ax.barh(ex["Feature"][::-1],ex["Importance"][::-1]); ax.set_xlabel("Relative importance"); ax.set_title("Top model features"); plt.tight_layout(); st.pyplot(fig); plt.close(fig)
    st.dataframe(ex,use_container_width=True,hide_index=True)
    st.caption("Feature importance indicates how much features contribute to the trained model's splits; it does not prove causation.")

elif page=="📊 Dashboard":
    h=history()
    if h.empty: st.info("No predictions yet.")
    else:
        approved=int(h.prediction.sum()); total=len(h)
        a,b,c,d=st.columns(4)
        a.metric("Predictions",total); b.metric("Approved",approved); c.metric("Rejected",total-approved); d.metric("Average probability",f"{h.approval_probability.mean():.1%}")
        st.markdown("### Decision distribution")
        st.bar_chart(pd.DataFrame({"Decision":["Approved","Rejected"],"Count":[approved,total-approved]}).set_index("Decision"))
        st.markdown("### Recent predictions")
        st.dataframe(h.head(20),use_container_width=True,hide_index=True)

elif page=="🗂️ History":
    h=history()
    st.dataframe(h,use_container_width=True,hide_index=True)
    if not h.empty:
        st.download_button("⬇️ Export CSV",h.to_csv(index=False).encode(),"creditwise_history.csv","text/csv")

elif page=="🔐 Admin":
    pwd=st.text_input("Admin password",type="password")
    expected=os.getenv("CREDITWISE_ADMIN_PASSWORD","creditwise123")
    if st.button("Login"):
        st.session_state["admin"]=pwd==expected
    if not st.session_state.get("admin"):
        st.warning("Admin login required.")
    else:
        h=history()
        st.success("Admin access granted.")
        st.metric("Stored predictions",len(h))
        if st.button("Clear prediction history"):
            con=db(); con.execute("DELETE FROM predictions"); con.commit(); con.close(); st.rerun()

st.markdown("---")
st.caption("Academic prototype. This prediction should not be used as the sole basis for real lending decisions.")
