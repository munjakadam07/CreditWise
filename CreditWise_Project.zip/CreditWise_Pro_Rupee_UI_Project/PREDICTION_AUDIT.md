# CreditWise Prediction Audit

## Problems found in the previous version

1. **Target-label bug:** 50 rows have missing `Loan_Approved`. The old code converted missing values to `0`, effectively labeling them as rejected.
2. **Out-of-distribution inputs:** the old UI allowed values far outside training ranges. Example: training `Loan_Amount` max = 39995, while exported tests used 2,000,000 and 9,000,000.
3. **Category mismatch:** the old UI did not expose all categories present in training data (`Contract`, `MNC`, `Business`).
4. **Model comparison:** the corrected model must be evaluated only on rows with known targets.

## Corrected result

Training rows: 950
Approved: 298
Rejected: 652

Holdout:
- Accuracy: 95.789%
- Precision: 90.625%
- Recall: 96.667%
- F1: 93.548%
- ROC-AUC: 98.769%

5-fold CV mean ROC-AUC: 98.766%

## Interpretation

The corrected Gradient Boosting model is substantially stronger than the previous evaluation. Its main feature importances are DTI ratio (~48%), credit score (~33%) and applicant income (~13%).

The app now refuses numeric inputs outside the observed training range rather than silently extrapolating.
