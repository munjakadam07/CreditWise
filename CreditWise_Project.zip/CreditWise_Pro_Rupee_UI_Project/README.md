# CreditWise Pro — Loan Approval Intelligence Platform

A college-level Streamlit project built around the CreditWise loan approval ML pipeline.

## Features

- AI loan approval prediction
- Approval probability
- Gradient Boosting final model
- Prediction history using SQLite
- CSV export of prediction history
- Admin login
- Admin history management
- Analytics dashboard
- Model feature importance / explainability
- Model comparison
- Streamlit Cloud deployment ready

## Run locally

```bash
pip install -r requirements.txt
streamlit run app.py
```

Default local admin password:

```text
creditwise123
```

For a real deployment, set the environment variable:

```text
CREDITWISE_ADMIN_PASSWORD
```

## Streamlit Cloud

1. Create a GitHub repository.
2. Upload all project files.
3. Open Streamlit Community Cloud.
4. Select the repository and `app.py`.
5. Deploy.
6. In the app settings, add secret/environment configuration as supported by your deployment setup.

### Important persistence note

SQLite is suitable for a college demonstration and local use. On hosted platforms with ephemeral/redeployable filesystems, prediction history may not be durable across restarts. For production persistence, replace SQLite with PostgreSQL or another managed database.

## Financial input representation

The application presents financial inputs in Indian rupees (₹). Loan amount is presented as ₹1–₹40 lakh for a realistic user experience. The application internally converts the entered values to the scale expected by the trained model; users do not need to know or enter any dataset-specific units.

## Model

The project compares Logistic Regression, KNN, Naive Bayes, Random Forest and Gradient Boosting. The final deployed model is Gradient Boosting based on the evaluation performed on the supplied dataset.

The model is stored as `creditwise_model.joblib` and includes preprocessing.
