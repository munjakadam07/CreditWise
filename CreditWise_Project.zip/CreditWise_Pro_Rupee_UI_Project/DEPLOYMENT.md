# CreditWise — Deployment & Production Operations Guide

This guide provides end-to-end instructions for deploying the **CreditWise Loan Approval Prediction System** using a decoupled full-stack architecture: React/Vite frontend, FastAPI backend, Scikit-learn ML pipeline, and SQLite database.

---

## 1. Architecture & Hosting Strategy

```
                                      +---------------------------------------------+
                                      |                Client Browser               |
                                      +---------------------------------------------+
                                                     |              ^
                                    HTTPS Requests   |              |  JSON APIs / JWT
                                                     v              |
+------------------------------------+        +-------------------------------------+
|        Frontend Static Host        |        |           Backend App Host          |
| (Cloudflare Pages / Vercel / Host) |        |   (Linux VM / Render with Volume)   |
|                                    |        |                                     |
|  - Pre-compiled React 18 / Vite    |        |  - FastAPI (Python 3.11 - 3.13)     |
|  - Recharts / Lucide UI            |        |  - Uvicorn ASGI Server              |
|  - Pure client-side routing        |        |  - Scikit-learn Pipeline (GB)       |
+------------------------------------+        +-------------------------------------+
                                                                 |
                                                                 v
                                              +-------------------------------------+
                                              |       Persistent Storage Disk       |
                                              |                                     |
                                              |  - creditwise_app.db (WAL mode)     |
                                              |  - Automated backups/ snapshots     |
                                              +-------------------------------------+
```

### Hosting Options & Storage Trade-Offs

| Component | Recommended Beginner Option | Alternative | Storage / Persistence Behavior |
| :--- | :--- | :--- | :--- |
| **Frontend** | **Cloudflare Pages / Vercel** | Netlify | Pure static edge delivery (`dist/` folder). Global CDN caching. Zero server storage needed. |
| **Backend API** | **Linux VPS (DigitalOcean / Hetzner)** or **Render Web Service with Disk** | Railway with Volume | **CRITICAL:** SQLite requires persistent block storage. Standard free-tier serverless or ephemeral containers discard local disk on restart or redeploy. You must mount a persistent disk volume to the database path. |
| **Database** | **SQLite (Persistent Volume)** | Managed PostgreSQL | SQLite with WAL mode (`PRAGMA journal_mode = WAL;`) and foreign keys is lightweight and fast for moderate scale. If multi-instance horizontal autoscaling is required in the future, migrate to managed PostgreSQL. |

> [!CAUTION]
> **Ephemeral Storage Warning:**
> Never deploy CreditWise to a container host with an ephemeral root filesystem without attaching a persistent storage volume. Doing so will wipe customer accounts and prediction history on every server redeploy or cold start.

---

## 2. Production Environment Configuration

All production secrets must be supplied via host environment variables or secret vaults. **Never commit real secrets or `.env` files to version control.**

### Backend Environment Variables (`backend`)

| Variable Name | Required | Example / Format | Purpose |
| :--- | :--- | :--- | :--- |
| `ENVIRONMENT` | Yes | `production` | Enables strict startup security checks and disables verbose error stack traces. |
| `SECRET_KEY` | Yes | `64-character hex or base64 string` | HMAC signing key for JWT tokens. Must be $\ge 32$ characters. |
| `ALGORITHM` | Yes | `HS256` | JWT signature algorithm. |
| `ACCESS_TOKEN_EXPIRE_MINUTES` | Yes | `120` | Session token lifespan (default: 2 hours). |
| `DATABASE_PATH` | Yes | `/var/data/creditwise_app.db` | Absolute path on persistent disk volume for SQLite storage. |
| `ALLOWED_ORIGINS` | Yes | `https://creditwise.yourdomain.com` | Strict CORS policy allowing only your production frontend origin. |
| `MODEL_PATH` | No | `creditwise_model.joblib` | Path to production Scikit-learn model artifact. |
| `FEATURE_RANGES_PATH` | No | `data/feature_ranges.json` | Path to observed feature ranges for OOD protection. |

#### Generating a Strong Secret Key
Run this command locally in PowerShell to generate a cryptographically secure 256-bit token:
```powershell
python -c "import secrets; print(secrets.token_urlsafe(48))"
```

### Frontend Environment Variables (`frontend`)

| Variable Name | Required | Example | Purpose |
| :--- | :--- | :--- | :--- |
| `VITE_API_BASE_URL` | Yes | `https://api.creditwise.yourdomain.com` | Points the React Axios client to your production backend domain. |

---

## 3. Administrator Bootstrap & Credential Rotation

### A. Initial Administrator Provisioning
To prevent security leaks, the application **does not** automatically create an administrator during startup in production.

Run the secure CLI provisioning tool in your deployment container or server terminal:
```powershell
python -m backend.seed_admin --email admin@yourorganization.com --name "Lead Administrator"
```
You will be prompted securely:
```
Enter secure administrator password: [hidden input]
[SUCCESS] Administrator account 'admin@yourorganization.com' successfully created.
```

*Notes on Administrative Security:*
1. Passwords are never logged, printed, or saved in plaintext; they are hashed with **Argon2id**.
2. Customer registration endpoints cannot grant administrative privileges; the role is hard-locked to `customer`.
3. Running `seed_admin` on an existing account upgrades the account without resetting passwords or corrupting records.

### B. JWT Secret Rotation Procedure
If you need to revoke active sessions or rotate a compromised secret:
1. Generate a new `SECRET_KEY` via `secrets.token_urlsafe(48)`.
2. Update the environment variable on your backend host.
3. Restart the backend service.
4. *Effect*: All currently issued JWT tokens immediately fail signature verification. Users are safely redirected to `/login?expired=true` and must re-authenticate. No database records or passwords are affected.

---

## 4. Database Persistence, Backups & Disaster Recovery

### A. Non-Blocking Online Backups
CreditWise uses SQLite in **Write-Ahead Logging (WAL)** mode. Backups must be performed using the non-blocking SQLite Backup API rather than a simple OS file copy to guarantee data consistency.

Run the backup utility:
```powershell
# Create an online snapshot in backups/
python -m backend.db_backup backup

# Verify database integrity and foreign key constraints
python -m backend.db_backup verify
```

### B. Automated Daily Backup (Cron Example)
On Linux/VPS, add a daily cron entry:
```bash
0 2 * * * cd /opt/creditwise && python -m backend.db_backup backup --dest /mnt/secure_backups/
```

### C. Database Restoration
If database recovery is required:
```powershell
python -m backend.db_backup restore --file backups/creditwise_backup_20261014_120000.db
```
The utility creates an emergency pre-restore snapshot of the active database before applying the backup, verifying foreign keys upon completion.

---

## 5. Local Production-Mode Verification

To test the production build and strict security checks locally on Windows:

### Step 1: Backend Startup
```powershell
# From project root
$env:ENVIRONMENT="development"
$env:PORT="8000"
$env:HOST="127.0.0.1"

python -m uvicorn backend.main:app --host 127.0.0.1 --port 8000
```
Verify `/health` via PowerShell:
```powershell
Invoke-RestMethod -Uri "http://127.0.0.1:8000/health"
```

### Step 2: Frontend Production Build & Preview
```powershell
# Navigate to frontend directory
cd frontend

# Build optimized distribution bundle
cmd /c "npm run build"

# Preview the production bundle locally
cmd /c "npm run preview -- --host 127.0.0.1 --port 5173"
```
Open `http://127.0.0.1:5173` in your browser.

---

## 6. Pre-Deployment Readiness Checklist

| Category | Item | Status | Verification Note |
| :--- | :--- | :--- | :--- |
| **Legacy Integrity** | Original `app.py` & `creditwise.db` preserved | **VERIFIED** | Unmodified; byte lengths and timestamps intact. |
| **Machine Learning** | Original `creditwise_model.joblib` active | **VERIFIED** | Loaded in `prediction_service.py` with 98.8% baseline. |
| **Currency Logic** | Single-step Rupee & Lakh conversion | **VERIFIED** | Inputs scaled in `prediction_service.py`; stored in DB. |
| **Model Comparison** | Real 3-model benchmark artifacts | **VERIFIED** | GB, RF, LR holdout metrics & confusion matrices saved in `data/`. |
| **Authentication** | RFC 9106 Argon2id password hashing | **VERIFIED** | Verified with unit tests; plaintext passwords never stored. |
| **Authorization** | Multi-tenant customer history isolation | **VERIFIED** | Strictly partitioned by user ID; customer cannot see other records. |
| **Admin Protection** | Backend checks on admin endpoints | **VERIFIED** | Non-admins blocked with HTTP 403 Forbidden. |
| **Abuse Prevention** | Rate limiter on `/auth/*` routes | **VERIFIED** | Excessive attempts trigger HTTP 429 Too Many Requests. |
| **Production Secrets** | Startup fails if `SECRET_KEY` is weak/default | **VERIFIED** | Tested via unit test; zero secrets bundled in frontend `dist/`. |
| **Test Coverage** | Full test suite execution | **VERIFIED** | 36/36 pytest passed; 4/4 frontend tests passed; 7/7 live API tests passed. |
| **Public Deployment**| Actual external host provisioning | **PENDING** | Awaiting user instruction before creating cloud services. |
